import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.Parser;
import org.apache.commons.cli.UnrecognizedOptionException;
import org.junit.Assert;
import org.junit.Test;

import java.util.ListIterator;
import java.util.Properties;

public class ParserTest {

    private static class ConcreteParser extends Parser {
        @Override
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }
    }

    @Test
    public void testParseBasic() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        options.addOption("a", "alpha", false, "alpha option");

        CommandLine cl = parser.parse(options, new String[]{"-a"});
        Assert.assertTrue(cl.hasOption("a"));
    }

    @Test(expected = UnrecognizedOptionException.class)
    public void testParseUnrecognizedOption() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();

        parser.parse(options, new String[]{"-unknown"});
    }

    @Test
    public void testParseWithProperties() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        options.addOption("b", "beta", true, "beta option");

        Properties props = new Properties();
        props.setProperty("b", "propValue");

        CommandLine cl = parser.parse(options, new String[0], props);
        Assert.assertTrue(cl.hasOption("b"));
        Assert.assertEquals("propValue", cl.getOptionValue("b"));
    }

    @Test
    public void testProcessArgs() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        Option opt = new Option("c", "charlie", true, "charlie option");
        options.addOption(opt);

        java.util.List<String> list = java.util.Arrays.asList("value1");
        ListIterator iter = list.listIterator();

        parser.processArgs(opt, iter);
        Assert.assertEquals("value1", opt.getValue());
    }
}
