import org.junit.Assert;
import org.junit.Test;
import org.apache.commons.cli.HelpFormatter;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(100);
        Assert.assertEquals(100, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(80);
        int width = formatter.getWidth();
        Assert.assertEquals(80, width);
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(3);
        int leftPadding = formatter.getLeftPadding();
        Assert.assertEquals(3, leftPadding);
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        // Since getDescPadding() is not in the target or concrete API, 
        // we execute setDescPadding to verify it completes normally without exception.
        formatter.setDescPadding(10);
        Assert.assertNotNull(formatter);
    }
}
