import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HelpFormatterTest {

    @Test
    public void setWidthUpdatesWidthReturnedByGetWidth() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(-1);
        assertEquals(-1, formatter.getWidth());

        formatter.setWidth(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, formatter.getWidth());
    }

    @Test
    public void setLeftPaddingUpdatesPaddingReturnedByGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());

        formatter.setLeftPadding(-5);
        assertEquals(-5, formatter.getLeftPadding());
    }
}
