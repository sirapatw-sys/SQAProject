import java.util.ArrayList;
import java.util.List;

import org.apache.commons.cli2.option.GroupImpl;
import org.junit.Assert;
import org.junit.Test;

public class GroupImplTest {

    @Test
    public void getPrefixesIsEmptyForGroupWithNoMembers() {
        GroupImpl group = new GroupImpl(new ArrayList(), "group", "description", 0, 1);

        Assert.assertTrue(group.getPrefixes().isEmpty());
    }

    @Test
    public void getTriggersIsEmptyForGroupWithNoMembers() {
        GroupImpl group = new GroupImpl(new ArrayList(), "group", "description", 0, 1);

        Assert.assertTrue(group.getTriggers().isEmpty());
    }

    @Test
    public void getPreferredNameReturnsConstructorName() {
        GroupImpl group = new GroupImpl(new ArrayList(), "preferred-name", "description", 0, 1);

        Assert.assertEquals("preferred-name", group.getPreferredName());
    }

    @Test
    public void getDescriptionReturnsConstructorDescription() {
        GroupImpl group = new GroupImpl(new ArrayList(), "group", "A group description", 0, 1);

        Assert.assertEquals("A group description", group.getDescription());
    }

    @Test
    public void getOptionsIsEmptyForGroupConstructedWithoutMembers() {
        List members = new ArrayList();
        GroupImpl group = new GroupImpl(members, "group", "description", 0, 1);

        Assert.assertTrue(group.getOptions().isEmpty());
        Assert.assertEquals(0, group.getOptions().size());
    }
}
