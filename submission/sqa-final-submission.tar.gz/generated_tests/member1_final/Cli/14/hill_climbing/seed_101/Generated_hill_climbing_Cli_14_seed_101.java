import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Cli_14_seed_101 {
  @Test
  public void test_getPrefixes_1() throws Exception {
    org.apache.commons.cli2.option.GroupImpl obj = new org.apache.commons.cli2.option.GroupImpl(new java.util.ArrayList(), "sqa", "sqa", 0, 0);
    assertNotNull(obj.getPrefixes());
  }
  @Test
  public void test_getTriggers_2() throws Exception {
    org.apache.commons.cli2.option.GroupImpl obj = new org.apache.commons.cli2.option.GroupImpl(new java.util.ArrayList(), "sqa", "sqa", 0, 0);
    assertNotNull(obj.getTriggers());
  }
  @Test
  public void test_getPreferredName_3() throws Exception {
    org.apache.commons.cli2.option.GroupImpl obj = new org.apache.commons.cli2.option.GroupImpl(new java.util.ArrayList(), "sqa", "sqa", 0, 0);
    assertEquals("sqa", obj.getPreferredName());
  }
  @Test
  public void test_getDescription_4() throws Exception {
    org.apache.commons.cli2.option.GroupImpl obj = new org.apache.commons.cli2.option.GroupImpl(new java.util.ArrayList(), "sqa", "sqa", 0, 0);
    assertEquals("sqa", obj.getDescription());
  }
  @Test
  public void test_getOptions_5() throws Exception {
    org.apache.commons.cli2.option.GroupImpl obj = new org.apache.commons.cli2.option.GroupImpl(new java.util.ArrayList(), "sqa", "sqa", 0, 0);
    assertNotNull(obj.getOptions());
  }
}
