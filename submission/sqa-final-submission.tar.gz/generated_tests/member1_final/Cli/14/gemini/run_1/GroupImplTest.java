import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.junit.Assert;
import org.junit.Test;
import org.apache.commons.cli2.option.GroupImpl;
import org.apache.commons.cli2.option.DefaultOption;

public class GroupImplTest {

    @Test
    public void testGetPrefixes() {
        List options = new ArrayList();
        GroupImpl group = new GroupImpl(options, "prefName", "desc", 0, 1);
        Set prefixes = group.getPrefixes();
        Assert.assertNotNull(prefixes);
    }

    @Test
    public void testGetTriggers() {
        List options = new ArrayList();
        GroupImpl group = new GroupImpl(options, "prefName", "desc", 0, 1);
        Set triggers = group.getTriggers();
        Assert.assertNotNull(triggers);
    }

    @Test
    public void testGetPreferredName() {
        List options = new ArrayList();
        GroupImpl group = new GroupImpl(options, "myPreferredName", "desc", 0, 1);
        String name = group.getPreferredName();
        Assert.assertEquals("myPreferredName", name);
    }

    @Test
    public void testGetDescription() {
        List options = new ArrayList();
        GroupImpl group = new GroupImpl(options, "prefName", "myDescription", 0, 1);
        String description = group.getDescription();
        Assert.assertEquals("myDescription", description);
    }

    @Test
    public void testGetOptions() {
        List options = new ArrayList();
        GroupImpl group = new GroupImpl(options, "prefName", "desc", 0, 1);
        List returnedOptions = group.getOptions();
        Assert.assertSame(options, returnedOptions);
    }
}
