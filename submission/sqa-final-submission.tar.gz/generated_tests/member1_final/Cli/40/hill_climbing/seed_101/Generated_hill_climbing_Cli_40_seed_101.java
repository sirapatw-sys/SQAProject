import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Cli_40_seed_101 {
  @Test
  public void test_createObject_1() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createObject("");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createObject_2() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createObject("test");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createObject_3() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createObject("-1");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createNumber_4() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createNumber("");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createNumber_5() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertEquals("0", String.valueOf(obj.createNumber("0")));
  }
  @Test
  public void test_createNumber_6() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertEquals("1", String.valueOf(obj.createNumber("1")));
  }
  @Test
  public void test_createClass_7() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createClass("");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createClass_8() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createClass(" ");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createClass_9() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createClass("test");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createDate_10() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createDate("");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.UnsupportedOperationException", caught.getClass().getName());
  }
  @Test
  public void test_createDate_11() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createDate("a");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.UnsupportedOperationException", caught.getClass().getName());
  }
  @Test
  public void test_createDate_12() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createDate("-1");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.UnsupportedOperationException", caught.getClass().getName());
  }
  @Test
  public void test_createURL_13() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createURL("");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createURL_14() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createURL("1");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
  @Test
  public void test_createURL_15() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    Throwable caught = null;
    try {
      obj.createURL(" ");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("org.apache.commons.cli.ParseException", caught.getClass().getName());
  }
}
