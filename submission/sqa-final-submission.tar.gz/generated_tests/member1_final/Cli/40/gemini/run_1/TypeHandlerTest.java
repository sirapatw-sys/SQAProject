import org.junit.Test;
import org.junit.Assert;

public class TypeHandlerTest {

    @Test
    public void testCreateObject() throws Exception {
        Object obj = TypeHandler.createObject("java.util.Date");
        Assert.assertNotNull(obj);
        Assert.assertTrue(obj instanceof java.util.Date);
    }

    @Test
    public void testCreateNumberLong() throws Exception {
        Number num = TypeHandler.createNumber("123");
        Assert.assertNotNull(num);
        Assert.assertTrue(num instanceof Long);
        Assert.assertEquals(123L, num.longValue());
    }

    @Test
    public void testCreateNumberDouble() throws Exception {
        Number num = TypeHandler.createNumber("123.45");
        Assert.assertNotNull(num);
        Assert.assertTrue(num instanceof Double);
        Assert.assertEquals(123.45, num.doubleValue(), 0.0001);
    }

    @Test
    public void testCreateClass() throws Exception {
        Class<?> cls = TypeHandler.createClass("java.lang.String");
        Assert.assertNotNull(cls);
        Assert.assertEquals(String.class, cls);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testCreateDate() {
        TypeHandler.createDate("2023-01-01");
    }

    @Test
    public void testCreateURL() throws Exception {
        java.net.URL url = TypeHandler.createURL("http://localhost/");
        Assert.assertNotNull(url);
        Assert.assertEquals("http", url.getProtocol());
        Assert.assertEquals("localhost", url.getHost());
    }
}
