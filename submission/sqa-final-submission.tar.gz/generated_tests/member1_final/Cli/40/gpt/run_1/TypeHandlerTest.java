import java.net.URL;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.TypeHandler;
import org.junit.Assert;
import org.junit.Test;

public class TypeHandlerTest {

    @Test
    public void createObjectCreatesInstanceUsingNoArgumentConstructor() throws ParseException {
        Object value = TypeHandler.createObject("java.lang.String");

        Assert.assertEquals(String.class, value.getClass());
        Assert.assertEquals("", value);
    }

    @Test
    public void createNumberCreatesDoubleWhenValueContainsDecimalPoint() throws ParseException {
        Number value = TypeHandler.createNumber("-12.5");

        Assert.assertEquals(Double.class, value.getClass());
        Assert.assertEquals(-12.5d, value.doubleValue(), 0.0d);
    }

    @Test
    public void createClassReturnsClassForFullyQualifiedName() throws ParseException {
        Class<?> value = TypeHandler.createClass("java.lang.String");

        Assert.assertEquals(String.class, value);
    }

    @Test
    public void createDateAlwaysThrowsUnsupportedOperationException() {
        try {
            TypeHandler.createDate("2020-01-01");
            Assert.fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            Assert.assertEquals("Not yet implemented", expected.getMessage());
        }
    }

    @Test
    public void createURLParsesWellFormedUrl() throws Exception {
        URL value = TypeHandler.createURL("https://example.com:8443/path?q=value#fragment");

        Assert.assertEquals("https", value.getProtocol());
        Assert.assertEquals("example.com", value.getHost());
        Assert.assertEquals(8443, value.getPort());
        Assert.assertEquals("/path", value.getPath());
        Assert.assertEquals("q=value", value.getQuery());
        Assert.assertEquals("fragment", value.getRef());
    }
}
