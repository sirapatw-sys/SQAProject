import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void testFlattenWithLongOptionAndEquals() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        String[] args = new String[] { "--foo=bar" };
        String[] flattened = parser.flatten(options, args, false);
        Assert.assertArrayEquals(new String[] { "--foo", "bar" }, flattened);
    }
}
