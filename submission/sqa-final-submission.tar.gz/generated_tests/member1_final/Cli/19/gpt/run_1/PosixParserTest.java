import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    private static class ExposedPosixParser extends PosixParser {
        String[] flattenForTest(Options options, String[] arguments, boolean stopAtNonOption) {
            return flatten(options, arguments, stopAtNonOption);
        }
    }

    @Test
    public void constructorCreatesParserWhoseFlatteningSplitsLongOptionValuesAndResetsState() {
        ExposedPosixParser parser = new ExposedPosixParser();

        Assert.assertArrayEquals(
                new String[] { "--name", "value", "plain" },
                parser.flattenForTest(null, new String[] { "--name=value", "plain" }, false));

        Assert.assertArrayEquals(
                new String[] { "-", "next" },
                parser.flattenForTest(null, new String[] { "-", "next" }, false));
    }
}
