import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.apache.commons.cli.OptionGroup;
import org.junit.Test;

public class OptionGroupTest {

    @Test
    public void getNamesReturnsEmptyCollectionForNewGroup() {
        OptionGroup group = new OptionGroup();

        assertTrue(group.getNames().isEmpty());
    }

    @Test
    public void getOptionsReturnsEmptyCollectionForNewGroup() {
        OptionGroup group = new OptionGroup();

        assertTrue(group.getOptions().isEmpty());
    }

    @Test
    public void getSelectedReturnsNullWhenNoOptionHasBeenSelected() {
        OptionGroup group = new OptionGroup();

        assertNull(group.getSelected());
    }

    @Test
    public void setRequiredUpdatesRequiredState() {
        OptionGroup group = new OptionGroup();

        group.setRequired(true);
        assertTrue(group.isRequired());

        group.setRequired(false);
        assertFalse(group.isRequired());
    }

    @Test
    public void isRequiredIsFalseForNewGroup() {
        OptionGroup group = new OptionGroup();

        assertFalse(group.isRequired());
    }
}
