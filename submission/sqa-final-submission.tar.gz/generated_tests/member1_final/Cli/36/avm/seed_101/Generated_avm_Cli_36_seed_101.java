import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_36_seed_101 {
  @Test
  public void test_getNames_1() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    assertNotNull(obj.getNames());
  }
  @Test
  public void test_getNames_2() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setRequired(false);
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertNotNull(obj.getNames());
  }
  @Test
  public void test_getNames_3() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertNotNull(obj.getNames());
  }
  @Test
  public void test_getOptions_4() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    assertNotNull(obj.getOptions());
  }
  @Test
  public void test_getOptions_5() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setRequired(false);
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertNotNull(obj.getOptions());
  }
  @Test
  public void test_getOptions_6() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertNotNull(obj.getOptions());
  }
  @Test
  public void test_getSelected_7() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    assertEquals("sqa", obj.getSelected());
  }
  @Test
  public void test_getSelected_8() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setRequired(false);
    assertNull(obj.getSelected());
  }
  @Test
  public void test_getSelected_9() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setRequired(false);
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertEquals("sqa", obj.getSelected());
  }
  @Test
  public void test_setRequired_10() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    assertFalse(obj.isRequired());
  }
  @Test
  public void test_setRequired_11() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(true);
    assertTrue(obj.isRequired());
  }
  @Test
  public void test_setRequired_12() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    obj.setRequired(false);
    assertFalse(obj.isRequired());
  }
  @Test
  public void test_isRequired_13() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    obj.setRequired(false);
    assertFalse(obj.isRequired());
  }
  @Test
  public void test_isRequired_14() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setRequired(false);
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertFalse(obj.isRequired());
  }
  @Test
  public void test_isRequired_15() throws Exception {
    org.apache.commons.cli.OptionGroup obj = new org.apache.commons.cli.OptionGroup();
    obj.setSelected(new org.apache.commons.cli.Option("sqa", "sqa"));
    assertFalse(obj.isRequired());
  }
}
