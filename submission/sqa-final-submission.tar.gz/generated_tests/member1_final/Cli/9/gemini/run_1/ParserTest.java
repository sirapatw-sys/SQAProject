import org.junit.Test;
import org.junit.Assert;
import java.util.Properties;

public class ParserTest {

    private static class ConcreteParser extends Parser {
        @Override
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }
    }

    @Test
    public void testParseNullArguments() throws Exception {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        CommandLine cl = parser.parse(options, null);
        Assert.assertNotNull(cl);
        Assert.assertEquals(0, cl.getArgs().length);
    }

    @Test
    public void testParseWithProperties() throws Exception {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        options.addOption("b", false, "Boolean option");
        
        Properties props = new Properties();
        props.setProperty("b", "true");

        CommandLine cl = parser.parse(options, new String[0], props);
        Assert.assertTrue(cl.hasOption("b"));
    }
}
