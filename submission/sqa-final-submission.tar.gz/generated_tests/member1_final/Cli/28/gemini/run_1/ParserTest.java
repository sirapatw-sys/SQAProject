import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.Parser;
import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class ParserTest {

    @Test
    public void testParseWithNullArguments() throws ParseException {
        Parser parser = new PosixParser();
        Options options = new Options();
        CommandLine cl = parser.parse(options, (String[]) null);
        Assert.assertNotNull(cl);
        Assert.assertEquals(0, cl.getArgs().length);
    }
}
