import org.junit.Assert;
import org.junit.Test;

public class OptionGroupTest {

    @Test
    public void testGetNames() {
        org.apache.commons.cli.OptionGroup group = new org.apache.commons.cli.OptionGroup();
        java.util.Collection names = group.getNames();
        Assert.assertNotNull(names);
        Assert.assertTrue(names.isEmpty());
    }

    @Test
    public void testGetOptions() {
        org.apache.commons.cli.OptionGroup group = new org.apache.commons.cli.OptionGroup();
        java.util.Collection options = group.getOptions();
        Assert.assertNotNull(options);
        Assert.assertTrue(options.isEmpty());
    }

    @Test
    public void testGetSelected() {
        org.apache.commons.cli.OptionGroup group = new org.apache.commons.cli.OptionGroup();
        Assert.assertNull(group.getSelected());
    }

    @Test
    public void testSetRequiredAndIsRequired() {
        org.apache.commons.cli.OptionGroup group = new org.apache.commons.cli.OptionGroup();
        Assert.assertFalse(group.isRequired());
        
        group.setRequired(true);
        Assert.assertTrue(group.isRequired());
        
        group.setRequired(false);
        Assert.assertFalse(group.isRequired());
    }
}
