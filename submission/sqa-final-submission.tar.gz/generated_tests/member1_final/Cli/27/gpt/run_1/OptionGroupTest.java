import java.util.Collection;

import org.apache.commons.cli.OptionGroup;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class OptionGroupTest {

    @Test
    public void testInitialCollectionsSelectionAndRequiredState() {
        OptionGroup group = new OptionGroup();

        Collection names = group.getNames();
        Collection options = group.getOptions();

        assertTrue(names.isEmpty());
        assertTrue(options.isEmpty());
        assertNull(group.getSelected());

        assertFalse(group.isRequired());
        group.setRequired(true);
        assertTrue(group.isRequired());
        group.setRequired(false);
        assertFalse(group.isRequired());
    }
}
