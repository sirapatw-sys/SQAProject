import org.apache.commons.cli.PosixParser;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class PosixParserTest {

    @Test
    public void createsPosixParserInstance() {
        assertNotNull(new PosixParser());
    }
}
