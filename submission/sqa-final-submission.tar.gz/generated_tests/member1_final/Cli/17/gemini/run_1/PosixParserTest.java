import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void testFlattenLongOptionWithEquals() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("b", "block", false, "block size");

        String[] args = new String[] { "--block=1024" };
        String[] flattened = parser.flatten(options, args, false);

        Assert.assertArrayEquals(new String[] { "--block", "1024" }, flattened);
    }
}
