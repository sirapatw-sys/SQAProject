import java.net.URL;

import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.TypeHandler;
import org.junit.Assert;
import org.junit.Test;

public class TypeHandlerTest {

    @Test
    public void createObjectInstantiatesClassUsingItsEmptyConstructor() throws Exception {
        Object created = TypeHandler.createObject("java.lang.String");

        Assert.assertTrue(created instanceof String);
        Assert.assertEquals("", created);
    }

    @Test
    public void createNumberChoosesDoubleForDecimalAndLongForIntegralValues() throws Exception {
        Number decimal = TypeHandler.createNumber("-12.5");
        Number integral = TypeHandler.createNumber("-12");

        Assert.assertTrue(decimal instanceof Double);
        Assert.assertEquals(-12.5d, decimal.doubleValue(), 0.0d);
        Assert.assertTrue(integral instanceof Long);
        Assert.assertEquals(-12L, integral.longValue());
    }

    @Test
    public void createClassFindsKnownClassAndReportsMissingClass() throws Exception {
        Assert.assertSame(String.class, TypeHandler.createClass("java.lang.String"));

        try {
            TypeHandler.createClass("definitely.not.a.real.ClassName");
            Assert.fail("Expected ParseException for an unavailable class");
        } catch (ParseException expected) {
            Assert.assertEquals(
                    "Unable to find the class: definitely.not.a.real.ClassName",
                    expected.getMessage());
        }
    }

    @Test
    public void createDateAlwaysReportsUnsupportedOperation() {
        try {
            TypeHandler.createDate("2020-01-01");
            Assert.fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            Assert.assertEquals("Not yet implemented", expected.getMessage());
        }
    }

    @Test
    public void createURLParsesWellFormedUrlAndRejectsMalformedUrl() throws Exception {
        URL url = TypeHandler.createURL("https://example.com:8443/path/item?key=value#section");

        Assert.assertEquals(
                "https://example.com:8443/path/item?key=value#section",
                url.toExternalForm());

        try {
            TypeHandler.createURL("not a valid url");
            Assert.fail("Expected ParseException for malformed URL");
        } catch (ParseException expected) {
            Assert.assertEquals(
                    "Unable to parse the URL: not a valid url",
                    expected.getMessage());
        }
    }
}
