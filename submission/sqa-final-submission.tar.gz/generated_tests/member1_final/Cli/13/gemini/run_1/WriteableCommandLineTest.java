import org.junit.Test;
import org.apache.commons.cli2.WriteableCommandLine;

public class WriteableCommandLineTest {

    @Test
    public void testAddProperty() {
        WriteableCommandLine wcl = new WriteableCommandLine() {
            private String savedProperty;
            private String savedValue;

            public void addProperty(String property, String value) {
                this.savedProperty = property;
                this.savedValue = value;
            }

            public boolean looksLikeOption(String argument) {
                return false;
            }

            public void addOption(org.apache.commons.cli2.Option option) {}
            public void addValue(org.apache.commons.cli2.Option option, Object value) {}
            public java.util.List getUndefaultedValues(org.apache.commons.cli2.Option option) { return null; }
            public void setDefaultValues(org.apache.commons.cli2.Option option, java.util.List defaultValues) {}
            public void addSwitch(org.apache.commons.cli2.Option option, boolean value) {}
            public void setDefaultSwitch(org.apache.commons.cli2.Option option, Boolean defaultSwitch) {}
            public java.util.Set getOptions() { return null; }
            public java.util.Set getOptionValues(org.apache.commons.cli2.Option option) { return null; }
            public java.util.List getValues(org.apache.commons.cli2.Option option) { return null; }
            public Object getValue(org.apache.commons.cli2.Option option) { return null; }
            public Object getValue(org.apache.commons.cli2.Option option, Object defaultValue) { return null; }
            public Boolean getSwitch(org.apache.commons.cli2.Option option) { return null; }
            public boolean getSwitch(org.apache.commons.cli2.Option option, boolean defaultValue) { return false; }
            public java.util.Map getProperties() { return null; }
            public String getProperty(String property) { return null; }
            public java.util.Set getPropertyNames() { return null; }
            public boolean hasOption(org.apache.commons.cli2.Option option) { return false; }
        };

        wcl.addProperty("testProp", "testVal");
    }

    @Test
    public void testLooksLikeOption() {
        WriteableCommandLine wcl = new WriteableCommandLine() {
            public void addProperty(String property, String value) {}
            public boolean looksLikeOption(String argument) {
                return argument != null && argument.startsWith("-");
            }

            public void addOption(org.apache.commons.cli2.Option option) {}
            public void addValue(org.apache.commons.cli2.Option option, Object value) {}
            public java.util.List getUndefaultedValues(org.apache.commons.cli2.Option option) { return null; }
            public void setDefaultValues(org.apache.commons.cli2.Option option, java.util.List defaultValues) {}
            public void addSwitch(org.apache.commons.cli2.Option option, boolean value) {}
            public void setDefaultSwitch(org.apache.commons.cli2.Option option, Boolean defaultSwitch) {}
            public java.util.Set getOptions() { return null; }
            public java.util.Set getOptionValues(org.apache.commons.cli2.Option option) { return null; }
            public java.util.List getValues(org.apache.commons.cli2.Option option) { return null; }
            public Object getValue(org.apache.commons.cli2.Option option) { return null; }
            public Object getValue(org.apache.commons.cli2.Option option, Object defaultValue) { return null; }
            public Boolean getSwitch(org.apache.commons.cli2.Option option) { return null; }
            public boolean getSwitch(org.apache.commons.cli2.Option option, boolean defaultValue) { return false; }
            public java.util.Map getProperties() { return null; }
            public String getProperty(String property) { return null; }
            public java.util.Set getPropertyNames() { return null; }
            public boolean hasOption(org.apache.commons.cli2.Option option) { return false; }
        };

        org.junit.Assert.assertTrue(wcl.looksLikeOption("-f"));
        org.junit.Assert.assertFalse(wcl.looksLikeOption("file.txt"));
    }
}
