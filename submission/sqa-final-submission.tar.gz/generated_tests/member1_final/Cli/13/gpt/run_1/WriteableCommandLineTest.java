import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.Set;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.commandline.CommandLineImpl;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class WriteableCommandLineTest {

    @Test
    public void addPropertyReplacesTheExistingPropertyValue() {
        CommandLineImpl commandLine = new CommandLineImpl();

        commandLine.addProperty("output", "first");
        commandLine.addProperty("output", "second");

        assertEquals("second", commandLine.getProperty("output"));
    }

    @Test
    public void looksLikeOptionRecognizesArgumentsWithARegisteredOptionPrefix() {
        CommandLineImpl commandLine = new CommandLineImpl();
        commandLine.addOption(createLongOption("--verbose", "verbose"));

        assertTrue(commandLine.looksLikeOption("--other-option"));
        assertFalse(commandLine.looksLikeOption("ordinary-value"));
    }

    private Option createLongOption(final String trigger, final String preferredName) {
        return (Option) Proxy.newProxyInstance(
                Option.class.getClassLoader(),
                new Class[] { Option.class },
                new InvocationHandler() {
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        if ("getTriggers".equals(method.getName())) {
                            return Collections.singleton(trigger);
                        }
                        if ("getPreferredName".equals(method.getName())) {
                            return preferredName;
                        }
                        if ("hashCode".equals(method.getName())) {
                            return Integer.valueOf(1);
                        }
                        if ("equals".equals(method.getName())) {
                            return Boolean.valueOf(proxy == args[0]);
                        }
                        if ("toString".equals(method.getName())) {
                            return preferredName;
                        }

                        Class returnType = method.getReturnType();
                        if (returnType == Boolean.TYPE) {
                            return Boolean.FALSE;
                        }
                        if (returnType == Integer.TYPE) {
                            return Integer.valueOf(0);
                        }
                        if (Set.class.isAssignableFrom(returnType)) {
                            return Collections.emptySet();
                        }
                        return null;
                    }
                });
    }
}
