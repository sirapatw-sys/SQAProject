import static org.junit.Assert.assertNotNull;

import org.apache.commons.cli.PosixParser;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void constructorCreatesParserInstance() {
        assertNotNull(new PosixParser());
    }
}
