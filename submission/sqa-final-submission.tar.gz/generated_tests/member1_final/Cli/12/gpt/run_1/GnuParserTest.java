public class GnuParserTest {
}
