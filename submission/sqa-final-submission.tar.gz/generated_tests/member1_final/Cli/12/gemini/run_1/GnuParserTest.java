import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.Option;
import org.junit.Assert;
import org.junit.Test;

public class GnuParserTest {

    @Test
    public void testGnuParserInstantiation() {
        GnuParser parser = new GnuParser();
        Assert.assertNotNull(parser);
    }
}
