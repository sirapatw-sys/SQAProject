import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.junit.Assert;
import org.junit.Test;

public class DefaultParserTest {

    @Test
    public void testParseBasic() throws ParseException {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption("a", "alpha", false, "alpha option");

        CommandLine cmd = parser.parse(options, new String[]{"-a"});
        Assert.assertTrue(cmd.hasOption("a"));
    }
}
