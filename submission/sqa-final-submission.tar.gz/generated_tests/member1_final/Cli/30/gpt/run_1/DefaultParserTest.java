public class DefaultParserTest {
}
