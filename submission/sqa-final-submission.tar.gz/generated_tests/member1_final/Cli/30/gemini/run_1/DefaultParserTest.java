import org.junit.Test;
import org.junit.Assert;
import java.util.Properties;

public class DefaultParserTest {

    @Test
    public void testParseWithOptionsAndArguments() throws Exception {
        Options options = new Options();
        options.addOption("a", "all", false, "do not hide entries starting with .");
        
        DefaultParser parser = new DefaultParser();
        String[] args = new String[]{"-a"};
        CommandLine cl = parser.parse(options, args);
        
        Assert.assertTrue(cl.hasOption("a"));
    }
}
