import org.junit.Test;
import org.junit.Assert;
import org.apache.commons.cli.HelpFormatter;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(100);
        Assert.assertEquals(100, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        int initialWidth = formatter.getWidth();
        Assert.assertEquals(initialWidth, formatter.getWidth());
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        int initialPadding = formatter.getLeftPadding();
        Assert.assertEquals(initialPadding, formatter.getLeftPadding());
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setDescPadding(7);
        // Since there is no public getDescPadding method, we test via setDescPadding execution
        // and can also verify other states remain consistent or instantiate properly.
        Assert.assertNotNull(formatter);
    }
}
