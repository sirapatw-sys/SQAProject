import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HelpFormatterTest {

    @Test
    public void widthRetainsAssignedBoundaryValues() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());

        formatter.setWidth(-17);
        assertEquals(-17, formatter.getWidth());
    }

    @Test
    public void leftPaddingRetainsAssignedBoundaryValues() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());

        formatter.setLeftPadding(-3);
        assertEquals(-3, formatter.getLeftPadding());
    }
}
