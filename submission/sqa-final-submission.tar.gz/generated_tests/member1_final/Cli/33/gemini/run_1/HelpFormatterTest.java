import org.junit.Assert;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(120);
        Assert.assertEquals(120, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        int initialWidth = formatter.getWidth();
        Assert.assertTrue(initialWidth > 0);
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(7);
        Assert.assertEquals(7, formatter.getLeftPadding());
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setDescPadding(10);
        // Since there is no getDescPadding in the target API, we verify setDescPadding runs cleanly
        // and doesn't throw exceptions.
        Assert.assertNotNull(formatter);
    }
}
