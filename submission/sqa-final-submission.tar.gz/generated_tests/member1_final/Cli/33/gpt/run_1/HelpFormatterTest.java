import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HelpFormatterTest {

    @Test
    public void settersUpdateTheirOwnObservableConfigurationValues() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(-17);
        formatter.setLeftPadding(0);

        assertEquals(-17, formatter.getWidth());
        assertEquals(0, formatter.getLeftPadding());

        formatter.setDescPadding(11);

        assertEquals(-17, formatter.getWidth());
        assertEquals(0, formatter.getLeftPadding());
    }
}
