import org.junit.Test;
import org.junit.Assert;
import org.apache.commons.cli.HelpFormatter;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(120);
        Assert.assertEquals(120, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(85);
        int width = formatter.getWidth();
        Assert.assertEquals(85, width);
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(3);
        int leftPad = formatter.getLeftPadding();
        Assert.assertEquals(3, leftPad);
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setDescPadding(10);
        // Since there is no public getDescPadding(), we just invoke setDescPadding to verify execution
        Assert.assertNotNull(formatter);
    }
}
