import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_24_seed_101 {
  @Test
  public void test_setWidth_1() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setWidth(0);
    assertEquals(0, obj.getWidth());
  }
  @Test
  public void test_setWidth_2() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setWidth(1);
    assertEquals(1, obj.getWidth());
  }
  @Test
  public void test_setWidth_3() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setWidth(-1);
    assertEquals(-1, obj.getWidth());
  }
  @Test
  public void test_getWidth_4() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    assertEquals(74, obj.getWidth());
  }
  @Test
  public void test_getWidth_5() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setDescPadding(0);
    assertEquals(74, obj.getWidth());
  }
  @Test
  public void test_getWidth_6() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    assertEquals(74, obj.getWidth());
  }
  @Test
  public void test_setLeftPadding_7() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setLeftPadding(0);
    assertEquals(0, obj.getLeftPadding());
  }
  @Test
  public void test_setLeftPadding_8() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setLeftPadding(1);
    assertEquals(1, obj.getLeftPadding());
  }
  @Test
  public void test_setLeftPadding_9() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setLeftPadding(-1);
    assertEquals(-1, obj.getLeftPadding());
  }
  @Test
  public void test_getLeftPadding_10() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    assertEquals(1, obj.getLeftPadding());
  }
  @Test
  public void test_getLeftPadding_11() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setDescPadding(0);
    assertEquals(1, obj.getLeftPadding());
  }
  @Test
  public void test_getLeftPadding_12() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    assertEquals(1, obj.getLeftPadding());
  }
  @Test
  public void test_setDescPadding_13() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setDescPadding(0);
    assertEquals(0, obj.getDescPadding());
  }
  @Test
  public void test_setDescPadding_14() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setDescPadding(1);
    assertEquals(1, obj.getDescPadding());
  }
  @Test
  public void test_setDescPadding_15() throws Exception {
    org.apache.commons.cli.HelpFormatter obj = new org.apache.commons.cli.HelpFormatter();
    obj.setOptionComparator(java.util.Comparator.naturalOrder());
    obj.setArgName("");
    obj.setDescPadding(-1);
    assertEquals(-1, obj.getDescPadding());
  }
}
