import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void setWidthUpdatesValueReturnedByGetWidth() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(Integer.MIN_VALUE);

        assertEquals(Integer.MIN_VALUE, formatter.getWidth());
    }

    @Test
    public void setLeftPaddingUpdatesValueReturnedByGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(-1);

        assertEquals(-1, formatter.getLeftPadding());
    }

    @Test
    public void setDescPaddingUpdatesDescriptionPaddingField() throws Exception {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setDescPadding(Integer.MAX_VALUE);

        Field field = HelpFormatter.class.getDeclaredField("defaultDescPad");
        field.setAccessible(true);
        assertEquals(Integer.MAX_VALUE, field.getInt(formatter));
    }
}
