import org.junit.Test;
import org.junit.Assert;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.Option;

public class DefaultParserTest {

    @Test
    public void testParseWithOptionsAndArguments() throws ParseException {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption("a", "all", false, "do not hide entries starting with .");
        
        String[] args = new String[] { "-a" };
        CommandLine cmd = parser.parse(options, args);
        
        Assert.assertNotNull(cmd);
        Assert.assertTrue(cmd.hasOption("a"));
    }
}
