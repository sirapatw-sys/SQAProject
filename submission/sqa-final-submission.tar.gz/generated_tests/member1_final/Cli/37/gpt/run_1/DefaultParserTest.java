import org.apache.commons.cli.DefaultParser;
import org.junit.Assert;
import org.junit.Test;

public class DefaultParserTest {

    @Test
    public void createsParserInstance() {
        DefaultParser parser = new DefaultParser();

        Assert.assertNotNull(parser);
    }
}
