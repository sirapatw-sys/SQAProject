import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.PropertyOption;
import org.junit.Assert;
import org.junit.Test;

public class WriteableCommandLineImplTest {

    @Test
    public void testGetOption() {
        List<String> prefixes = new ArrayList<String>();
        prefixes.add("-");
        WriteableCommandLineImpl cmd = new WriteableCommandLineImpl(null, prefixes);
        Option opt = cmd.getOption("nonexistent");
        Assert.assertNull(opt);
    }

    @Test
    public void testGetProperty() {
        List<String> prefixes = new ArrayList<String>();
        WriteableCommandLineImpl cmd = new WriteableCommandLineImpl(null, prefixes);
        String val = cmd.getProperty("prop1");
        Assert.assertNull(val);
    }

    @Test
    public void testAddProperty() {
        List<String> prefixes = new ArrayList<String>();
        WriteableCommandLineImpl cmd = new WriteableCommandLineImpl(null, prefixes);
        cmd.addProperty("prop1", "val1");
        Assert.assertEquals("val1", cmd.getProperty("prop1"));
    }

    @Test
    public void testGetProperties() {
        List<String> prefixes = new ArrayList<String>();
        WriteableCommandLineImpl cmd = new WriteableCommandLineImpl(null, prefixes);
        cmd.addProperty("prop1", "val1");
        Set props = cmd.getProperties();
        Assert.assertNotNull(props);
    }

    @Test
    public void testLooksLikeOption() {
        List<String> prefixes = new ArrayList<String>();
        prefixes.add("-");
        prefixes.add("--");
        WriteableCommandLineImpl cmd = new WriteableCommandLineImpl(null, prefixes);
        
        Assert.assertTrue(cmd.looksLikeOption("-f"));
        Assert.assertTrue(cmd.looksLikeOption("--file"));
        Assert.assertFalse(cmd.looksLikeOption("file"));
    }
}
