import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.junit.Assert;
import org.junit.Test;

public class WriteableCommandLineImplTest {

    private WriteableCommandLineImpl newCommandLine(final Set prefixes) {
        final Option rootOption = (Option) Proxy.newProxyInstance(
                Option.class.getClassLoader(),
                new Class[] { Option.class },
                new InvocationHandler() {
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        if ("getPrefixes".equals(method.getName())) {
                            return prefixes;
                        }
                        if ("equals".equals(method.getName())) {
                            return Boolean.valueOf(proxy == args[0]);
                        }
                        if ("hashCode".equals(method.getName())) {
                            return Integer.valueOf(System.identityHashCode(proxy));
                        }
                        if ("toString".equals(method.getName())) {
                            return "rootOption";
                        }

                        final Class returnType = method.getReturnType();
                        if (returnType == Boolean.TYPE) {
                            return Boolean.FALSE;
                        }
                        if (returnType == Byte.TYPE) {
                            return Byte.valueOf((byte) 0);
                        }
                        if (returnType == Short.TYPE) {
                            return Short.valueOf((short) 0);
                        }
                        if (returnType == Integer.TYPE) {
                            return Integer.valueOf(0);
                        }
                        if (returnType == Long.TYPE) {
                            return Long.valueOf(0L);
                        }
                        if (returnType == Float.TYPE) {
                            return Float.valueOf(0.0f);
                        }
                        if (returnType == Double.TYPE) {
                            return Double.valueOf(0.0d);
                        }
                        if (returnType == Character.TYPE) {
                            return Character.valueOf('\0');
                        }
                        if (Set.class.isAssignableFrom(returnType)) {
                            return Collections.emptySet();
                        }
                        if (List.class.isAssignableFrom(returnType)) {
                            return Collections.emptyList();
                        }
                        if (Map.class.isAssignableFrom(returnType)) {
                            return Collections.emptyMap();
                        }
                        return null;
                    }
                });

        return new WriteableCommandLineImpl(rootOption, Collections.EMPTY_LIST);
    }

    @Test
    public void getOptionReturnsNullForAnUnknownTrigger() {
        final WriteableCommandLineImpl commandLine = newCommandLine(Collections.EMPTY_SET);

        Assert.assertNull(commandLine.getOption("--unknown"));
    }

    @Test
    public void getPropertyReturnsNullWhenNoSuchPropertyHasBeenAdded() {
        final WriteableCommandLineImpl commandLine = newCommandLine(Collections.EMPTY_SET);

        Assert.assertNull(commandLine.getProperty("missing"));
    }

    @Test
    public void addPropertyMakesItsValueAvailableThroughGetProperty() {
        final WriteableCommandLineImpl commandLine = newCommandLine(Collections.EMPTY_SET);

        commandLine.addProperty("environment", "production");

        Assert.assertEquals("production", commandLine.getProperty("environment"));
    }

    @Test
    public void getPropertiesContainsEveryAddedPropertyName() {
        final WriteableCommandLineImpl commandLine = newCommandLine(Collections.EMPTY_SET);
        commandLine.addProperty("first", "one");
        commandLine.addProperty("second", "two");

        final Set properties = commandLine.getProperties();

        Assert.assertEquals(2, properties.size());
        Assert.assertTrue(properties.contains("first"));
        Assert.assertTrue(properties.contains("second"));
    }

    @Test
    public void looksLikeOptionRecognizesConfiguredPrefixesOnly() {
        final Set prefixes = new LinkedHashSet();
        prefixes.add("--");
        prefixes.add("-");
        final WriteableCommandLineImpl commandLine = newCommandLine(prefixes);

        Assert.assertTrue(commandLine.looksLikeOption("--verbose"));
        Assert.assertTrue(commandLine.looksLikeOption("-v"));
        Assert.assertFalse(commandLine.looksLikeOption("verbose"));
    }
}
