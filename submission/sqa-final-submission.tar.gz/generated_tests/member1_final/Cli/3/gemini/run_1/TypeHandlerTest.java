import org.junit.Test;
import org.junit.Assert;

public class TypeHandlerTest {

    @Test
    public void testCreateObject() {
        Object obj = TypeHandler.createObject("java.lang.Object");
        Assert.assertNotNull(obj);
        Assert.assertEquals(Object.class, obj.getClass());
    }

    @Test
    public void testCreateNumberLong() {
        Number num = TypeHandler.createNumber("123");
        Assert.assertNotNull(num);
        Assert.assertEquals(Long.class, num.getClass());
        Assert.assertEquals(123L, num.longValue());
    }

    @Test
    public void testCreateNumberDouble() {
        Number num = TypeHandler.createNumber("123.45");
        Assert.assertNotNull(num);
        Assert.assertEquals(Double.class, num.getClass());
        Assert.assertEquals(123.45, num.doubleValue(), 0.0001);
    }

    @Test
    public void testCreateClass() {
        Class<?> clazz = TypeHandler.createClass("java.lang.String");
        Assert.assertNotNull(clazz);
        Assert.assertEquals(String.class, clazz);
    }

    @Test
    public void testCreateDate() {
        // Based on the fixed source, createDate always returns null
        java.util.Date date = TypeHandler.createDate("2023-01-01");
        Assert.assertNull(date);
    }

    @Test
    public void testCreateURL() {
        java.net.URL url = TypeHandler.createURL("http://localhost/");
        Assert.assertNotNull(url);
        Assert.assertEquals("http", url.getProtocol());
    }
}
