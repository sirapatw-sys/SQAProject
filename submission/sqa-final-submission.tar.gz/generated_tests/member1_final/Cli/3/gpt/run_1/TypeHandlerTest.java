import java.net.URL;

import org.apache.commons.cli.TypeHandler;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class TypeHandlerTest {

    @Test
    public void createObjectCreatesPublicNoArgumentInstancesAndReturnsNullForUnknownClass() {
        Object object = TypeHandler.createObject("java.lang.String");

        assertTrue(object instanceof String);
        assertEquals("", object);
        assertNull(TypeHandler.createObject("no.such.TypeHandlerTestClass"));
    }

    @Test
    public void createNumberSelectsLongOrDoubleAndReturnsNullForInvalidValues() {
        Number integer = TypeHandler.createNumber("-42");
        Number decimal = TypeHandler.createNumber("3.5");

        assertTrue(integer instanceof Long);
        assertEquals(-42L, integer.longValue());
        assertTrue(decimal instanceof Double);
        assertEquals(3.5d, decimal.doubleValue(), 0.0d);
        assertNull(TypeHandler.createNumber("not-a-number"));
        assertNull(TypeHandler.createNumber(null));
    }

    @Test
    public void createClassReturnsResolvedClassAndNullWhenClassDoesNotExist() {
        assertEquals(String.class, TypeHandler.createClass("java.lang.String"));
        assertNull(TypeHandler.createClass("no.such.TypeHandlerTestClass"));
    }

    @Test
    public void createDateAlwaysReturnsNull() {
        assertNull(TypeHandler.createDate("2020-01-01"));
    }

    @Test
    public void createURLReturnsWellFormedUrlAndNullForMalformedUrl() throws Exception {
        URL url = TypeHandler.createURL("http://example.com/path?x=1");

        assertEquals("http://example.com/path?x=1", url.toExternalForm());
        assertNull(TypeHandler.createURL("not a valid url"));
    }
}
