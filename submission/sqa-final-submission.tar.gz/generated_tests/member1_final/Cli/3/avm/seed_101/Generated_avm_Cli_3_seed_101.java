import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_3_seed_101 {
  @Test
  public void test_createObject_1() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createObject(""));
  }
  @Test
  public void test_createObject_2() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createObject("a"));
  }
  @Test
  public void test_createObject_3() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createObject("0"));
  }
  @Test
  public void test_createNumber_4() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createNumber(""));
  }
  @Test
  public void test_createNumber_5() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertEquals("0", String.valueOf(obj.createNumber("0")));
  }
  @Test
  public void test_createNumber_6() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertEquals("1", String.valueOf(obj.createNumber("1")));
  }
  @Test
  public void test_createClass_7() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createClass(""));
  }
  @Test
  public void test_createClass_8() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createClass("a"));
  }
  @Test
  public void test_createClass_9() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createClass("0"));
  }
  @Test
  public void test_createDate_10() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createDate(""));
  }
  @Test
  public void test_createDate_11() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createDate("a"));
  }
  @Test
  public void test_createDate_12() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createDate("0"));
  }
  @Test
  public void test_createURL_13() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createURL(""));
  }
  @Test
  public void test_createURL_14() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createURL("a"));
  }
  @Test
  public void test_createURL_15() throws Exception {
    org.apache.commons.cli.TypeHandler obj = new org.apache.commons.cli.TypeHandler();
    assertNull(obj.createURL("0"));
  }
}
