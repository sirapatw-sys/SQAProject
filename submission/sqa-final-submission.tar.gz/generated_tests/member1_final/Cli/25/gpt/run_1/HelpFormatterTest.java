import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void widthCanBeUpdatedAndReadBackForNegativeAndZeroValues() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(-1);
        assertEquals(-1, formatter.getWidth());

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());
    }

    @Test
    public void leftPaddingCanBeUpdatedAndReadBackForNegativeAndZeroValues() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(-4);
        assertEquals(-4, formatter.getLeftPadding());

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());
    }

    @Test
    public void descPaddingStoresTheProvidedValue() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        Field descPadding = HelpFormatter.class.getDeclaredField("defaultDescPad");
        descPadding.setAccessible(true);

        formatter.setDescPadding(-2);
        assertEquals(-2, descPadding.getInt(formatter));

        formatter.setDescPadding(0);
        assertEquals(0, descPadding.getInt(formatter));
    }
}
