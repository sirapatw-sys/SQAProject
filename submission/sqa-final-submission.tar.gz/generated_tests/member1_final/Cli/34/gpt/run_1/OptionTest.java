import org.apache.commons.cli.Option;
import org.junit.Assert;
import org.junit.Test;

public class OptionTest {

    @Test
    public void getIdReturnsFirstCharacterOfShortOption() {
        Option option = new Option("x", "example option");

        Assert.assertEquals((int) 'x', option.getId());
    }

    @Test
    public void getOptReturnsConstructorShortOption() {
        Option option = new Option("verbose", "verbose output");

        Assert.assertEquals("verbose", option.getOpt());
    }

    @Test
    public void getTypeReturnsTypeAssignedWithSetType() {
        Option option = new Option("n", "number");
        option.setType(Integer.class);

        Assert.assertSame(Integer.class, option.getType());
    }

    @Test
    public void setLongOptUpdatesLongOptionAndAllowsNull() {
        Option option = new Option("o", "output");
        option.setLongOpt("output");

        Assert.assertEquals("output", option.getLongOpt());

        option.setLongOpt(null);

        Assert.assertNull(option.getLongOpt());
    }
}
