import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_34_seed_101 {
  @Test
  public void test_getId_1() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    assertEquals(115, obj.getId());
  }
  @Test
  public void test_getId_2() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgs(0);
    assertEquals(115, obj.getId());
  }
  @Test
  public void test_getId_3() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setDescription("");
    assertEquals(115, obj.getId());
  }
  @Test
  public void test_getOpt_4() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    assertEquals("sqa", obj.getOpt());
  }
  @Test
  public void test_getOpt_5() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgs(0);
    assertEquals("sqa", obj.getOpt());
  }
  @Test
  public void test_getOpt_6() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setDescription("");
    assertEquals("sqa", obj.getOpt());
  }
  @Test
  public void test_getType_7() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    assertNotNull(obj.getType());
  }
  @Test
  public void test_getType_8() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgs(0);
    assertNotNull(obj.getType());
  }
  @Test
  public void test_getType_9() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setDescription("");
    assertNotNull(obj.getType());
  }
  @Test
  public void test_getLongOpt_10() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    assertNull(obj.getLongOpt());
  }
  @Test
  public void test_getLongOpt_11() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgs(0);
    assertNull(obj.getLongOpt());
  }
  @Test
  public void test_getLongOpt_12() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setDescription("");
    assertNull(obj.getLongOpt());
  }
  @Test
  public void test_setLongOpt_13() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    obj.setLongOpt("");
    assertEquals("", obj.getLongOpt());
  }
  @Test
  public void test_setLongOpt_14() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    obj.setLongOpt("a");
    assertEquals("a", obj.getLongOpt());
  }
  @Test
  public void test_setLongOpt_15() throws Exception {
    org.apache.commons.cli.Option obj = new org.apache.commons.cli.Option("sqa", "sqa");
    obj.setArgName("");
    obj.setLongOpt("0");
    assertEquals("0", obj.getLongOpt());
  }
}
