import org.junit.Test;
import org.junit.Assert;

public class OptionTest {

    @Test
    public void testGetId() throws Exception {
        org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("a", "description");
        Assert.assertEquals('a', option.getId());
    }

    @Test
    public void testGetOpt() throws Exception {
        org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("b", "description");
        Assert.assertEquals("b", option.getOpt());
    }

    @Test
    public void testGetType() throws Exception {
        org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("c", "description");
        option.setType(java.lang.Integer.class);
        Assert.assertEquals(java.lang.Integer.class, option.getType());
    }

    @Test
    public void testGetLongOpt() throws Exception {
        org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("d", "longD", true, "description");
        Assert.assertEquals("longD", option.getLongOpt());
    }

    @Test
    public void testSetLongOpt() throws Exception {
        org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("e", "description");
        option.setLongOpt("newLongOpt");
        Assert.assertEquals("newLongOpt", option.getLongOpt());
    }
}
