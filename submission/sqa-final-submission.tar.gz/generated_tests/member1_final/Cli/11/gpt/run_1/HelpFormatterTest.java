import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void setWidthUpdatesValueReturnedByGetWidth() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());

        formatter.setWidth(-19);
        assertEquals(-19, formatter.getWidth());
    }

    @Test
    public void setLeftPaddingUpdatesValueReturnedByGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());

        formatter.setLeftPadding(-7);
        assertEquals(-7, formatter.getLeftPadding());
    }

    @Test
    public void setDescPaddingStoresTheProvidedValue() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        Field descPadding = HelpFormatter.class.getDeclaredField("defaultDescPad");
        descPadding.setAccessible(true);

        formatter.setDescPadding(0);
        assertEquals(0, descPadding.getInt(formatter));

        formatter.setDescPadding(-5);
        assertEquals(-5, descPadding.getInt(formatter));
    }
}
