import org.junit.Assert;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(120);
        Assert.assertEquals(120, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        int initialWidth = formatter.getWidth();
        Assert.assertEquals(initialWidth, formatter.getWidth());
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(10);
        Assert.assertEquals(10, formatter.getLeftPadding());
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setDescPadding(4);
        // Since there is no public getDescPadding(), we can verify setDescPadding executes normally
        // or check that it doesn't throw. We can also test setWidth again or another modifier if needed.
        Assert.assertNotNull(formatter);
    }
}
