import org.apache.commons.cli.Options;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void testConstructor() {
        PosixParser parser = new PosixParser();
        Assert.assertNotNull(parser);
    }
}
