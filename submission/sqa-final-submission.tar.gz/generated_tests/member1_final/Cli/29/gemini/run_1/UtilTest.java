import org.junit.Test;
import org.junit.Assert;

public class UtilTest {

    @Test
    public void testStripLeadingHyphensNull() {
        Assert.assertNull(Util.stripLeadingHyphens(null));
    }

    @Test
    public void testStripLeadingHyphensDouble() {
        Assert.assertEquals("foo", Util.stripLeadingHyphens("--foo"));
    }

    @Test
    public void testStripLeadingHyphensSingle() {
        Assert.assertEquals("foo", Util.stripLeadingHyphens("-foo"));
    }

    @Test
    public void testStripLeadingHyphensNone() {
        Assert.assertEquals("foo", Util.stripLeadingHyphens("foo"));
    }

    @Test
    public void testStripLeadingAndTrailingQuotesMatch() {
        Assert.assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two\""));
    }

    @Test
    public void testStripLeadingAndTrailingQuotesNoMatch() {
        Assert.assertEquals("\"one two", Util.stripLeadingAndTrailingQuotes("\"one two"));
    }
}
