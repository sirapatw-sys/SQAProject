import org.junit.Test;
import org.junit.Assert;

public class UtilTest {

    @Test
    public void testStripLeadingHyphens() {
        Assert.assertNull(Util.stripLeadingHyphens(null));
        Assert.assertEquals("foo", Util.stripLeadingHyphens("--foo"));
        Assert.assertEquals("foo", Util.stripLeadingHyphens("-foo"));
        Assert.assertEquals("foo", Util.stripLeadingHyphens("foo"));
    }

    @Test
    public void testStripLeadingAndTrailingQuotes() {
        Assert.assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two\""));
        Assert.assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two"));
        Assert.assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two\""));
        Assert.assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two"));
    }
}
