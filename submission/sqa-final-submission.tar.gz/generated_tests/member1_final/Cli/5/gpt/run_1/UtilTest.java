import java.lang.reflect.Method;

import org.junit.Assert;
import org.junit.Test;

public class UtilTest {

    private String invokeStringMethod(String methodName, String value) throws Exception {
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method method = utilClass.getDeclaredMethod(methodName, String.class);
        method.setAccessible(true);
        return (String) method.invoke(null, new Object[] { value });
    }

    @Test
    public void stripLeadingHyphensRemovesAtMostTwoLeadingHyphens() throws Exception {
        Assert.assertNull(invokeStringMethod("stripLeadingHyphens", null));
        Assert.assertEquals("", invokeStringMethod("stripLeadingHyphens", "-"));
        Assert.assertEquals("", invokeStringMethod("stripLeadingHyphens", "--"));
        Assert.assertEquals("option", invokeStringMethod("stripLeadingHyphens", "-option"));
        Assert.assertEquals("option", invokeStringMethod("stripLeadingHyphens", "--option"));
        Assert.assertEquals("-option", invokeStringMethod("stripLeadingHyphens", "---option"));
        Assert.assertEquals("option", invokeStringMethod("stripLeadingHyphens", "option"));
    }

    @Test
    public void stripLeadingAndTrailingQuotesRemovesQuotesIndependently() throws Exception {
        Assert.assertEquals("one two",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "\"one two\""));
        Assert.assertEquals("one two",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "\"one two"));
        Assert.assertEquals("one two",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "one two\""));
        Assert.assertEquals("one two",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "one two"));
        Assert.assertEquals("",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "\"\""));
        Assert.assertEquals("",
                invokeStringMethod("stripLeadingAndTrailingQuotes", "\""));
    }
}
