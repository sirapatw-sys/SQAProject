import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.junit.Assert;
import org.junit.Test;

public class OptionTest {

    @Test
    public void getTriggersReturnsTheOptionTriggers() {
        final Option option = new ContractOption();

        final Set triggers = option.getTriggers();

        Assert.assertEquals(
            new LinkedHashSet(Arrays.asList("--verbose", "-v")),
            triggers);
        Assert.assertTrue(triggers.contains("--verbose"));
        Assert.assertTrue(triggers.contains("-v"));
    }

    @Test
    public void getPrefixesReturnsTheOptionPrefixes() {
        final Option option = new ContractOption();

        final Set prefixes = option.getPrefixes();

        Assert.assertEquals(
            new LinkedHashSet(Arrays.asList("--", "-")),
            prefixes);
        Assert.assertTrue(prefixes.contains("--"));
        Assert.assertTrue(prefixes.contains("-"));
    }

    @Test
    public void getPreferredNameReturnsConfiguredName() {
        final Option option = new ContractOption();

        Assert.assertEquals("verbose", option.getPreferredName());
    }

    @Test
    public void getDescriptionReturnsConfiguredDescription() {
        final Option option = new ContractOption();

        Assert.assertEquals(
            "Print detailed processing information.",
            option.getDescription());
    }

    @Test
    public void getIdReturnsConfiguredIdIncludingNegativeValues() {
        final Option option = new ContractOption();

        Assert.assertEquals(-17, option.getId());
    }

    private static final class ContractOption implements Option {
        private final Set triggers = Collections.unmodifiableSet(
            new LinkedHashSet(Arrays.asList("--verbose", "-v")));
        private final Set prefixes = Collections.unmodifiableSet(
            new LinkedHashSet(Arrays.asList("--", "-")));

        public void process(
            final WriteableCommandLine commandLine,
            final ListIterator args) throws OptionException {
        }

        public void defaults(final WriteableCommandLine commandLine) {
        }

        public boolean canProcess(
            final WriteableCommandLine commandLine,
            final String argument) {
            return false;
        }

        public boolean canProcess(
            final WriteableCommandLine commandLine,
            final ListIterator arguments) {
            return false;
        }

        public Set getTriggers() {
            return triggers;
        }

        public Set getPrefixes() {
            return prefixes;
        }

        public void validate(final WriteableCommandLine commandLine)
            throws OptionException {
        }

        public List helpLines(
            final int depth,
            final Set helpSettings,
            final Comparator comp) {
            return Collections.EMPTY_LIST;
        }

        public void appendUsage(
            final StringBuffer buffer,
            final Set helpSettings,
            final Comparator comp) {
        }

        public String getPreferredName() {
            return "verbose";
        }

        public String getDescription() {
            return "Print detailed processing information.";
        }

        public int getId() {
            return -17;
        }

        public Option findOption(final String trigger) {
            return null;
        }

        public boolean isRequired() {
            return false;
        }

        public Option getParent() {
            return null;
        }

        public void setParent(final Option parent) {
        }
    }
}
