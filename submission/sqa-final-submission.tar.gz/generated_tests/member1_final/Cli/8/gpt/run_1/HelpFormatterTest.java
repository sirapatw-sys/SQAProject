import java.lang.reflect.Field;

import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HelpFormatterTest {

    @Test
    public void setWidthUpdatesValueReturnedByGetWidth() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(-1);
        assertEquals(-1, formatter.getWidth());

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());
    }

    @Test
    public void setLeftPaddingUpdatesValueReturnedByGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(-3);
        assertEquals(-3, formatter.getLeftPadding());

        formatter.setLeftPadding(5);
        assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void setDescPaddingUpdatesDefaultDescriptionPadding() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        Field descPadding = HelpFormatter.class.getDeclaredField("defaultDescPad");
        descPadding.setAccessible(true);

        formatter.setDescPadding(-2);
        assertEquals(-2, descPadding.getInt(formatter));

        formatter.setDescPadding(8);
        assertEquals(8, descPadding.getInt(formatter));
    }
}
