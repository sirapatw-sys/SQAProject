import org.junit.Test;
import org.junit.Assert;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;

public class HelpFormatterTest {

    @Test
    public void testSetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(100);
        Assert.assertEquals(100, formatter.getWidth());
    }

    @Test
    public void testGetWidth() {
        HelpFormatter formatter = new HelpFormatter();
        // Check default or explicitly set value
        formatter.setWidth(80);
        Assert.assertEquals(80, formatter.getWidth());
    }

    @Test
    public void testSetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(5);
        Assert.assertEquals(5, formatter.getLeftPadding());
    }

    @Test
    public void testGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLeftPadding(3);
        Assert.assertEquals(3, formatter.getLeftPadding());
    }

    @Test
    public void testSetDescPadding() {
        HelpFormatter formatter = new HelpFormatter();
        // Since there is no public getDescPadding method in the API, 
        // we can invoke printHelp to ensure setDescPadding executes cleanly without throwing an exception.
        formatter.setDescPadding(7);
        Options options = new Options();
        formatter.printHelp("testCmd", options);
        // If no exception is thrown, state is accepted successfully.
        Assert.assertTrue(true);
    }
}
