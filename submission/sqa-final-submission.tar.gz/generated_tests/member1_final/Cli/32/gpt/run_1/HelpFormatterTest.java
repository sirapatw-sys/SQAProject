import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.cli.HelpFormatter;
import org.junit.Test;

public class HelpFormatterTest {

    @Test
    public void setWidthUpdatesValueReturnedByGetWidth() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());

        formatter.setWidth(-25);
        assertEquals(-25, formatter.getWidth());
    }

    @Test
    public void setLeftPaddingUpdatesValueReturnedByGetLeftPadding() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());

        formatter.setLeftPadding(-3);
        assertEquals(-3, formatter.getLeftPadding());
    }

    @Test
    public void setDescPaddingUpdatesDescriptionPaddingField() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        Field descPadding = HelpFormatter.class.getDeclaredField("defaultDescPad");
        descPadding.setAccessible(true);

        formatter.setDescPadding(0);
        assertEquals(0, descPadding.getInt(formatter));

        formatter.setDescPadding(-4);
        assertEquals(-4, descPadding.getInt(formatter));
    }
}
