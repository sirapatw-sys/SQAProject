import org.apache.commons.cli.CommandLine;
import org.junit.Assert;
import org.junit.Test;

public class CommandLineTest {

    @Test
    public void testHasOptionString() {
        CommandLine cmd = new CommandLine();
        Assert.assertFalse(cmd.hasOption("a"));
    }

    @Test
    public void testHasOptionChar() {
        CommandLine cmd = new CommandLine();
        Assert.assertFalse(cmd.hasOption('a'));
    }

    @Test
    public void testGetOptionObjectString() {
        CommandLine cmd = new CommandLine();
        Assert.assertNull(cmd.getOptionObject("a"));
    }

    @Test
    public void testGetOptionObjectChar() {
        CommandLine cmd = new CommandLine();
        Assert.assertNull(cmd.getOptionObject('a'));
    }

    @Test
    public void testGetOptionValueString() {
        CommandLine cmd = new CommandLine();
        Assert.assertNull(cmd.getOptionValue("a"));
    }

}
