import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class CommandLineTest {

    @Test
    public void hasOptionStringRecognizesShortAndLongNamesWithLeadingHyphens() throws Exception {
        Options options = new Options();
        options.addOption(new Option("v", "verbose", false, "verbose output"));

        CommandLine commandLine = new PosixParser().parse(options, new String[] { "-v" });

        assertTrue(commandLine.hasOption("v"));
        assertTrue(commandLine.hasOption("-v"));
        assertTrue(commandLine.hasOption("verbose"));
        assertTrue(commandLine.hasOption("--verbose"));
        assertFalse(commandLine.hasOption("missing"));
    }

    @Test
    public void hasOptionCharReflectsWhetherTheShortOptionWasParsed() throws Exception {
        Options options = new Options();
        options.addOption(new Option("q", false, "quiet mode"));

        CommandLine commandLine = new PosixParser().parse(options, new String[] { "-q" });

        assertTrue(commandLine.hasOption('q'));
        assertFalse(commandLine.hasOption('x'));
    }

    @Test
    public void getOptionObjectStringConvertsConfiguredStringTypeAndReturnsNullForMissingOption() throws Exception {
        Options options = new Options();
        Option name = new Option("n", true, "name");
        name.setType(String.class);
        options.addOption(name);

        CommandLine commandLine = new PosixParser().parse(options, new String[] { "-n", "alice" });

        assertEquals("alice", commandLine.getOptionObject("n"));
        assertNull(commandLine.getOptionObject("missing"));
    }

    @Test
    public void getOptionObjectCharUsesTheShortOptionValueAndConfiguredType() throws Exception {
        Options options = new Options();
        Option source = new Option("s", true, "source");
        source.setType(String.class);
        options.addOption(source);

        CommandLine commandLine = new PosixParser().parse(options, new String[] { "-s", "input.txt" });

        assertEquals("input.txt", commandLine.getOptionObject('s'));
        assertNull(commandLine.getOptionObject('x'));
    }

    @Test
    public void getOptionValueStringReturnsArgumentAndNullForFlagOrMissingOption() throws Exception {
        Options options = new Options();
        options.addOption(new Option("p", true, "path"));
        options.addOption(new Option("f", false, "flag"));

        CommandLine commandLine = new PosixParser().parse(
                options, new String[] { "-p", "/tmp/data", "-f" });

        assertEquals("/tmp/data", commandLine.getOptionValue("p"));
        assertNull(commandLine.getOptionValue("f"));
        assertNull(commandLine.getOptionValue("missing"));
    }
}
