import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.WriteableCommandLine;
import org.junit.Assert;
import org.junit.Test;

public class WriteableCommandLineTest {

    @Test
    public void addPropertyDeclaresStringPropertyAndValueArguments() throws Exception {
        Method method = WriteableCommandLine.class.getMethod(
                "addProperty", String.class, String.class);

        Assert.assertEquals(Void.TYPE, method.getReturnType());
        Assert.assertTrue(Modifier.isAbstract(method.getModifiers()));
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    @Test
    public void looksLikeOptionDeclaresBooleanResultForAnArgument() throws Exception {
        Method method = WriteableCommandLine.class.getMethod(
                "looksLikeOption", String.class);

        Assert.assertEquals(Boolean.TYPE, method.getReturnType());
        Assert.assertTrue(Modifier.isAbstract(method.getModifiers()));
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    @Test
    public void getCurrentOptionDeclaresOptionResult() throws Exception {
        Method method = WriteableCommandLine.class.getMethod("getCurrentOption");

        Assert.assertEquals(Option.class, method.getReturnType());
        Assert.assertTrue(Modifier.isAbstract(method.getModifiers()));
        Assert.assertTrue(Modifier.isPublic(method.getModifiers()));
    }
}
