import org.apache.commons.cli.PosixParser;
import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void constructorCreatesParserInstance() {
        PosixParser parser = new PosixParser();

        Assert.assertNotNull(parser);
    }
}
