import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Cli_7_seed_101 {
  @Test
  public void test_create_1() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    obj.withPattern("");
    assertNotNull(obj.create());
  }
  @Test
  public void test_create_2() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    assertNotNull(obj.create());
  }
  @Test
  public void test_reset_3() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    obj.withPattern("");
    assertSame(obj, obj.reset());
  }
  @Test
  public void test_reset_4() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    assertSame(obj, obj.reset());
  }
  @Test
  public void test_withPattern_5() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    obj.withPattern("");
    obj.withPattern("null");
  }
  @Test
  public void test_withPattern_6() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    obj.withPattern("");
    obj.withPattern("test");
  }
  @Test
  public void test_withPattern_7() throws Exception {
    org.apache.commons.cli2.builder.PatternBuilder obj = new org.apache.commons.cli2.builder.PatternBuilder();
    obj.withPattern("");
    obj.withPattern("-1");
  }
}
