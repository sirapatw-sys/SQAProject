import org.junit.Assert;
import org.junit.Test;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.PatternBuilder;

public class PatternBuilderTest {

    @Test
    public void testWithPattern() {
        PatternBuilder builder = new PatternBuilder();
        builder.withPattern("a");
        Option option = builder.create();
        Assert.assertNotNull(option);
    }

    @Test
    public void testCreate() {
        PatternBuilder builder = new PatternBuilder();
        builder.withPattern("a>b");
        Option option = builder.create();
        Assert.assertNotNull(option);
    }

    @Test
    public void testReset() {
        PatternBuilder builder = new PatternBuilder();
        builder.withPattern("a");
        PatternBuilder resetBuilder = builder.reset();
        Assert.assertSame(builder, resetBuilder);
    }
}
