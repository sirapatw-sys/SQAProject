import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.PatternBuilder;
import org.junit.Assert;
import org.junit.Test;

public class PatternBuilderTest {

    @Test
    public void createBuildsAnOptionForASinglePatternOption() {
        PatternBuilder builder = new PatternBuilder();
        builder.withPattern("a");

        Option option = builder.create();

        Assert.assertNotNull(option);
    }

    @Test
    public void resetReturnsTheSameBuilderInstance() {
        PatternBuilder builder = new PatternBuilder();

        Assert.assertSame(builder, builder.reset());
    }

    @Test(expected = NullPointerException.class)
    public void withPatternRejectsNullPattern() {
        new PatternBuilder().withPattern(null);
    }
}
