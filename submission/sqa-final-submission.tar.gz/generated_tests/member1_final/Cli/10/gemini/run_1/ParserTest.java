import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.MissingOptionException;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.Parser;
import org.apache.commons.cli.UnrecognizedOptionException;
import org.junit.Assert;
import org.junit.Test;

import java.util.Properties;

public class ParserTest {

    private static class ConcreteParser extends Parser {
        @Override
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }
    }

    @Test
    public void testParseBasic() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        options.addOption("a", false, "alpha");
        
        CommandLine cl = parser.parse(options, new String[]{"-a"});
        Assert.assertTrue(cl.hasOption("a"));
    }

    @Test(expected = UnrecognizedOptionException.class)
    public void testParseUnrecognizedOption() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        
        parser.parse(options, new String[]{"-b"});
    }

    @Test(expected = MissingOptionException.class)
    public void testCheckRequiredOptionsMissing() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        Option reqOpt = new Option("r", "required option");
        reqOpt.setRequired(true);
        options.addOption(reqOpt);

        parser.parse(options, new String[]{});
    }

    @Test
    public void testParseWithProperties() throws ParseException {
        Parser parser = new ConcreteParser();
        Options options = new Options();
        options.addOption("p", true, "property option");

        Properties props = new Properties();
        props.setProperty("p", "val");

        CommandLine cl = parser.parse(options, new String[]{}, props, false);
        Assert.assertTrue(cl.hasOption("p"));
        Assert.assertEquals("val", cl.getOptionValue("p"));
    }
}
