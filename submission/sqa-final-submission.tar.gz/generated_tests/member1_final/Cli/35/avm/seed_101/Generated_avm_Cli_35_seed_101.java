import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_35_seed_101 {
  @Test
  public void test_addOption_1() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", ""));
  }
  @Test
  public void test_addOption_2() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    Throwable caught = null;
    try {
      obj.addOption("-1", "");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_addOption_3() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", "a"));
  }
  @Test
  public void test_addOption_4() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", false, ""));
  }
  @Test
  public void test_addOption_5() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    Throwable caught = null;
    try {
      obj.addOption("-1", false, "");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_addOption_6() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", false, "a"));
  }
  @Test
  public void test_addOption_7() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", "", false, ""));
  }
  @Test
  public void test_addOption_8() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    Throwable caught = null;
    try {
      obj.addOption("-1", "", false, "");
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_addOption_9() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertSame(obj, obj.addOption("", "", true, ""));
  }
  @Test
  public void test_getOptions_10() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertNotNull(obj.getOptions());
  }
  @Test
  public void test_getRequiredOptions_11() throws Exception {
    org.apache.commons.cli.Options obj = new org.apache.commons.cli.Options();
    assertNotNull(obj.getRequiredOptions());
  }
}
