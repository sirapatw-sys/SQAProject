import java.util.Collection;
import java.util.List;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.junit.Assert;
import org.junit.Test;

public class OptionsTest {

    @Test
    public void addOptionWithShortNameAndDescriptionReturnsSameInstanceAndAddsOption() {
        Options options = new Options();

        Options returned = options.addOption("a", "activate");

        Assert.assertSame(options, returned);
        Assert.assertEquals(1, options.getOptions().size());
    }

    @Test
    public void addOptionWithArgumentFlagReturnsSameInstanceAndAddsOption() {
        Options options = new Options();

        Options returned = options.addOption("b", true, "base directory");

        Assert.assertSame(options, returned);
        Assert.assertEquals(1, options.getOptions().size());
    }

    @Test
    public void addOptionWithShortAndLongNamesReturnsSameInstanceAndAddsOption() {
        Options options = new Options();

        Options returned = options.addOption("c", "config", true, "configuration file");

        Assert.assertSame(options, returned);
        Assert.assertEquals(1, options.getOptions().size());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getOptionsReturnsAnUnmodifiableCollectionContainingAddedOptions() {
        Options options = new Options();
        options.addOption("d", "debug");

        Collection<Option> exposedOptions = options.getOptions();

        Assert.assertEquals(1, exposedOptions.size());
        exposedOptions.clear();
    }

    @Test(expected = UnsupportedOperationException.class)
    @SuppressWarnings("unchecked")
    public void getRequiredOptionsReturnsAnUnmodifiableList() {
        Options options = new Options();

        List requiredOptions = options.getRequiredOptions();

        Assert.assertTrue(requiredOptions.isEmpty());
        requiredOptions.add("unexpected");
    }
}
