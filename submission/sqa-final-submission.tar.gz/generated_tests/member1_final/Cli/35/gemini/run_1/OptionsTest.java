import org.junit.Test;
import org.junit.Assert;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.Option;
import java.util.Collection;
import java.util.List;

public class OptionsTest {

    @Test
    public void testAddOptionShortAndDesc() {
        Options options = new Options();
        Options result = options.addOption("a", "description-a");
        Assert.assertSame(options, result);
        Collection<Option> opts = options.getOptions();
        Assert.assertEquals(1, opts.size());
        Option opt = opts.iterator().next();
        Assert.assertEquals("a", opt.getOpt());
        Assert.assertEquals("description-a", opt.getDescription());
        Assert.assertFalse(opt.hasArg());
    }

    @Test
    public void testAddOptionShortBoolAndDesc() {
        Options options = new Options();
        Options result = options.addOption("b", true, "description-b");
        Assert.assertSame(options, result);
        Collection<Option> opts = options.getOptions();
        Assert.assertEquals(1, opts.size());
        Option opt = opts.iterator().next();
        Assert.assertEquals("b", opt.getOpt());
        Assert.assertTrue(opt.hasArg());
        Assert.assertEquals("description-b", opt.getDescription());
    }

    @Test
    public void testAddOptionFull() {
        Options options = new Options();
        Options result = options.addOption("c", "long-c", true, "description-c");
        Assert.assertSame(options, result);
        Collection<Option> opts = options.getOptions();
        Assert.assertEquals(1, opts.size());
        Option opt = opts.iterator().next();
        Assert.assertEquals("c", opt.getOpt());
        Assert.assertEquals("long-c", opt.getLongOpt());
        Assert.assertTrue(opt.hasArg());
        Assert.assertEquals("description-c", opt.getDescription());
    }

    @Test
    public void testGetOptions() {
        Options options = new Options();
        options.addOption("d", "description-d");
        Collection<Option> opts = options.getOptions();
        Assert.assertNotNull(opts);
        Assert.assertEquals(1, opts.size());
    }

    @Test
    public void testGetRequiredOptions() {
        Options options = new Options();
        List required = options.getRequiredOptions();
        Assert.assertNotNull(required);
        Assert.assertTrue(required.isEmpty());
    }
}
