import org.junit.Assert;
import org.junit.Test;

public class PosixParserTest {

    @Test
    public void testFlattenWithStopAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", "alpha", false, "alpha option");

        String[] args = new String[] { "-a", "non-option", "-a" };
        String[] flattened = parser.flatten(options, args, true);

        Assert.assertArrayEquals(new String[] { "-a", "--", "non-option", "-a" }, flattened);
    }
}
