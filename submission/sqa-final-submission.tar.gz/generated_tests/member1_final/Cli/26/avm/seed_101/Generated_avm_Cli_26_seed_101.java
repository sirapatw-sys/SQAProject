import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Cli_26_seed_101 {
  @Test
  public void test_withLongOpt_1() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withLongOpt(""));
  }
  @Test
  public void test_withLongOpt_2() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withLongOpt("a"));
  }
  @Test
  public void test_withLongOpt_3() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withLongOpt("0"));
  }
  @Test
  public void test_hasArg_4() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.hasArg());
  }
  @Test
  public void test_hasArg_5() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.hasArg(true));
  }
  @Test
  public void test_hasArg_6() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.hasArg(false));
  }
  @Test
  public void test_withArgName_7() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withArgName(""));
  }
  @Test
  public void test_withArgName_8() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withArgName("a"));
  }
  @Test
  public void test_withArgName_9() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.withArgName("0"));
  }
  @Test
  public void test_isRequired_10() throws Exception {
    org.apache.commons.cli.OptionBuilder obj = org.apache.commons.cli.OptionBuilder.hasArg();
    assertSame(obj, obj.isRequired());
  }
}
