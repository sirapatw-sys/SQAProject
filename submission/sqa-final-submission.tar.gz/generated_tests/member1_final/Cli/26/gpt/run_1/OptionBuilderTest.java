import java.lang.reflect.Field;

import org.apache.commons.cli.OptionBuilder;
import org.junit.Assert;
import org.junit.Test;

public class OptionBuilderTest {

    @Test
    public void withLongOptStoresProvidedValueIncludingNull() throws Exception {
        Field longopt = staticField(OptionBuilder.class, "longopt");
        Object original = longopt.get(null);

        try {
            OptionBuilder builder = OptionBuilder.withLongOpt("output-file");

            Assert.assertSame(builderInstance(), builder);
            Assert.assertEquals("output-file", longopt.get(null));

            builder = OptionBuilder.withLongOpt(null);

            Assert.assertSame(builderInstance(), builder);
            Assert.assertNull(longopt.get(null));
        } finally {
            longopt.set(null, original);
        }
    }

    @Test
    public void hasArgSetsNumberOfArgumentsToOne() throws Exception {
        Field numberOfArgs = staticField(OptionBuilder.class, "numberOfArgs");
        int original = numberOfArgs.getInt(null);

        try {
            numberOfArgs.setInt(null, 0);

            OptionBuilder builder = OptionBuilder.hasArg();

            Assert.assertSame(builderInstance(), builder);
            Assert.assertEquals(1, numberOfArgs.getInt(null));
        } finally {
            numberOfArgs.setInt(null, original);
        }
    }

    @Test
    public void hasArgBooleanSelectsArgumentRequirement() throws Exception {
        Field numberOfArgs = staticField(OptionBuilder.class, "numberOfArgs");
        int original = numberOfArgs.getInt(null);
        int uninitialized = staticField(Class.forName("org.apache.commons.cli.Option"),
                "UNINITIALIZED").getInt(null);

        try {
            OptionBuilder builder = OptionBuilder.hasArg(true);

            Assert.assertSame(builderInstance(), builder);
            Assert.assertEquals(1, numberOfArgs.getInt(null));

            builder = OptionBuilder.hasArg(false);

            Assert.assertSame(builderInstance(), builder);
            Assert.assertEquals(uninitialized, numberOfArgs.getInt(null));
        } finally {
            numberOfArgs.setInt(null, original);
        }
    }

    @Test
    public void withArgNameStoresProvidedNameIncludingNull() throws Exception {
        Field argName = staticField(OptionBuilder.class, "argName");
        Object original = argName.get(null);

        try {
            OptionBuilder builder = OptionBuilder.withArgName("destination");

            Assert.assertSame(builderInstance(), builder);
            Assert.assertEquals("destination", argName.get(null));

            builder = OptionBuilder.withArgName(null);

            Assert.assertSame(builderInstance(), builder);
            Assert.assertNull(argName.get(null));
        } finally {
            argName.set(null, original);
        }
    }

    @Test
    public void isRequiredSetsRequiredFlagToTrue() throws Exception {
        Field required = staticField(OptionBuilder.class, "required");
        boolean original = required.getBoolean(null);

        try {
            required.setBoolean(null, false);

            OptionBuilder builder = OptionBuilder.isRequired();

            Assert.assertSame(builderInstance(), builder);
            Assert.assertTrue(required.getBoolean(null));
        } finally {
            required.setBoolean(null, original);
        }
    }

    private static OptionBuilder builderInstance() throws Exception {
        return (OptionBuilder) staticField(OptionBuilder.class, "instance").get(null);
    }

    private static Field staticField(Class<?> type, String name) throws Exception {
        Field field = type.getDeclaredField(name);
        field.setAccessible(true);
        return field;
    }
}
