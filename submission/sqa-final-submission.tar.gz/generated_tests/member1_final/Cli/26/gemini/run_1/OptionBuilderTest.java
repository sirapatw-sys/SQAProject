import org.junit.Assert;
import org.junit.Test;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Option;

public class OptionBuilderTest {

    @Test
    public void testWithLongOpt() {
        OptionBuilder.withLongOpt("test-long-opt");
        Option option = OptionBuilder.create('t');
        Assert.assertEquals("test-long-opt", option.getLongOpt());
    }

    @Test
    public void testHasArg() {
        OptionBuilder.hasArg();
        Option option = OptionBuilder.create('a');
        Assert.assertEquals(1, option.getNumberOfArgs());
    }

    @Test
    public void testHasArgBoolean() {
        OptionBuilder.hasArg(false);
        Option option = OptionBuilder.create('b');
        Assert.assertEquals(Option.UNINITIALIZED, option.getNumberOfArgs());
    }

    @Test
    public void testWithArgName() {
        OptionBuilder.withArgName("argNameValue");
        Option option = OptionBuilder.create('c');
        Assert.assertEquals("argNameValue", option.getArgName());
    }

    @Test
    public void testIsRequired() {
        OptionBuilder.isRequired();
        Option option = OptionBuilder.create('d');
        Assert.assertTrue(option.isRequired());
    }
}
