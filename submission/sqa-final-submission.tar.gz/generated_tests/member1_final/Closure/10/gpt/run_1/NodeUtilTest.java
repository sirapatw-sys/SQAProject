import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import com.google.javascript.jscomp.NodeUtil;
import com.google.javascript.rhino.jstype.TernaryValue;
import org.junit.Test;

public class NodeUtilTest {

  @Test
  public void isStrWhiteSpaceCharDistinguishesKnownWhitespaceAndAmbiguousVerticalTab() {
    assertEquals(TernaryValue.UNKNOWN, NodeUtil.isStrWhiteSpaceChar('\u000B'));
    assertEquals(TernaryValue.TRUE, NodeUtil.isStrWhiteSpaceChar(' '));
    assertEquals(TernaryValue.TRUE, NodeUtil.isStrWhiteSpaceChar('\u2028'));
    assertEquals(TernaryValue.FALSE, NodeUtil.isStrWhiteSpaceChar('a'));
  }

  @Test
  public void isValidQualifiedNameRejectsNamesWithLeadingOrTrailingDot() {
    assertFalse(NodeUtil.isValidQualifiedName(".property"));
    assertFalse(NodeUtil.isValidQualifiedName("object.property."));
  }
}
