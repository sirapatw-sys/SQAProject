import org.junit.Test;
import org.junit.Assert;
import com.google.javascript.jscomp.NodeUtil;
import com.google.javascript.rhino.jstype.TernaryValue;

public class NodeUtilTest {

    @Test
    public void testIsStrWhiteSpaceChar() {
        // Test a known whitespace character (' ') -> TRUE
        Assert.assertEquals(TernaryValue.TRUE, NodeUtil.isStrWhiteSpaceChar(' '));
        
        // Test vertical tab ('\u000B') -> UNKNOWN
        Assert.assertEquals(TernaryValue.UNKNOWN, NodeUtil.isStrWhiteSpaceChar('\u000B'));
        
        // Test a non-whitespace character ('a') -> FALSE
        Assert.assertEquals(TernaryValue.FALSE, NodeUtil.isStrWhiteSpaceChar('a'));
    }

    @Test
    public void testIsValidQualifiedName() {
        // Valid qualified name
        Assert.assertTrue(NodeUtil.isValidQualifiedName("a.b.c"));
        
        // Invalid qualified name ending with a dot
        Assert.assertFalse(NodeUtil.isValidQualifiedName("a.b."));
        
        // Invalid qualified name starting with a dot
        Assert.assertFalse(NodeUtil.isValidQualifiedName(".a.b"));
    }
}
