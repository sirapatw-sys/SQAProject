public class RemoveUnusedVarsTest {
}
