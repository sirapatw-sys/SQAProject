import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_4_seed_101 {
  @Test
  public void test_getPlotType_1() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertEquals("XY Plot", obj.getPlotType());
  }
  @Test
  public void test_getPlotType_2() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertEquals("XY Plot", obj.getPlotType());
  }
  @Test
  public void test_getPlotType_3() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertEquals("XY Plot", obj.getPlotType());
  }
  @Test
  public void test_getOrientation_4() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNotNull(obj.getOrientation());
  }
  @Test
  public void test_getOrientation_5() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNotNull(obj.getOrientation());
  }
  @Test
  public void test_getOrientation_6() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNotNull(obj.getOrientation());
  }
  @Test
  public void test_getAxisOffset_7() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNotNull(obj.getAxisOffset());
  }
  @Test
  public void test_getAxisOffset_8() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNotNull(obj.getAxisOffset());
  }
  @Test
  public void test_getAxisOffset_9() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNotNull(obj.getAxisOffset());
  }
  @Test
  public void test_getDomainAxis_10() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNull(obj.getDomainAxis());
  }
  @Test
  public void test_getDomainAxis_11() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNull(obj.getDomainAxis());
  }
  @Test
  public void test_getDomainAxis_12() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0));
    assertNull(obj.getDomainAxis());
  }
  @Test
  public void test_getDomainAxis_13() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNull(obj.getDomainAxis(0));
  }
  @Test
  public void test_getDomainAxis_14() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNull(obj.getDomainAxis(-1));
  }
  @Test
  public void test_getDomainAxis_15() throws Exception {
    org.jfree.chart.plot.XYPlot obj = new org.jfree.chart.plot.XYPlot();
    obj.addDomainMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addRangeMarker(new org.jfree.chart.plot.ValueMarker(0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNull(obj.getDomainAxis(1));
  }
}
