import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.util.RectangleInsets;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class XYPlotTest {

    @Test
    public void getPlotTypeReturnsStableLocalizedName() {
        XYPlot plot = new XYPlot();

        String plotType = plot.getPlotType();

        assertNotNull(plotType);
        assertEquals(plotType, plot.getPlotType());
    }

    @Test
    public void getOrientationReturnsTheStoredNonNullOrientation() {
        XYPlot plot = new XYPlot();

        PlotOrientation orientation = plot.getOrientation();

        assertNotNull(orientation);
        assertSame(orientation, plot.getOrientation());
    }

    @Test
    public void getAxisOffsetReturnsTheStoredNonNullInsets() {
        XYPlot plot = new XYPlot();

        RectangleInsets offset = plot.getAxisOffset();

        assertNotNull(offset);
        assertSame(offset, plot.getAxisOffset());
    }

    @Test
    public void getDomainAxisReturnsNullWhenNoAxisOrParentIsConfigured() {
        XYPlot plot = new XYPlot();

        assertNull(plot.getDomainAxis());
    }

    @Test
    public void getDomainAxisWithOutOfRangeIndexReturnsNullWithoutParentAxis() {
        XYPlot plot = new XYPlot();

        assertNull(plot.getDomainAxis(Integer.MAX_VALUE));
    }
}
