import org.junit.Test;
import org.junit.Assert;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.axis.ValueAxis;

public class XYPlotTest {

    @Test
    public void testGetPlotType() {
        XYPlot plot = new XYPlot();
        String plotType = plot.getPlotType();
        Assert.assertNotNull(plotType);
    }

    @Test
    public void testGetOrientation() {
        XYPlot plot = new XYPlot();
        PlotOrientation orientation = plot.getOrientation();
        Assert.assertNotNull(orientation);
        Assert.assertEquals(PlotOrientation.VERTICAL, orientation);
    }

    @Test
    public void testGetAxisOffset() {
        XYPlot plot = new XYPlot();
        RectangleInsets axisOffset = plot.getAxisOffset();
        Assert.assertNotNull(axisOffset);
    }

    @Test
    public void testGetDomainAxis() {
        XYPlot plot = new XYPlot();
        ValueAxis axis = plot.getDomainAxis();
        // Default constructor sets up a default domain axis at index 0
        Assert.assertNotNull(axis);
    }

    @Test
    public void testGetDomainAxisWithIndex() {
        XYPlot plot = new XYPlot();
        ValueAxis axis = plot.getDomainAxis(0);
        Assert.assertNotNull(axis);
        
        ValueAxis invalidAxis = plot.getDomainAxis(99);
        Assert.assertNull(invalidAxis);
    }
}
