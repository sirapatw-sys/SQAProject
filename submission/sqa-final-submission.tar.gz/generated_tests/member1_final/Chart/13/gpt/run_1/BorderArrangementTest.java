import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.jfree.chart.block.Block;
import org.jfree.chart.block.BorderArrangement;
import org.junit.Assert;
import org.junit.Test;

public class BorderArrangementTest {

    @Test
    public void clearRemovesAllStoredBlocks() throws Exception {
        BorderArrangement arrangement = new BorderArrangement();
        Block block = (Block) Proxy.newProxyInstance(
                Block.class.getClassLoader(),
                new Class[] { Block.class },
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        return null;
                    }
                });

        String[] fieldNames = {
            "centerBlock", "topBlock", "bottomBlock", "leftBlock", "rightBlock"
        };

        for (String fieldName : fieldNames) {
            Field field = BorderArrangement.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(arrangement, block);
            Assert.assertSame(block, field.get(arrangement));
        }

        arrangement.clear();

        for (String fieldName : fieldNames) {
            Field field = BorderArrangement.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            Assert.assertNull(fieldName + " should be cleared", field.get(arrangement));
        }
    }
}
