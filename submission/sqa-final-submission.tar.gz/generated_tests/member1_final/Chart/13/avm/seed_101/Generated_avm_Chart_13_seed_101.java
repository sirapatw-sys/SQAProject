import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_13_seed_101 {
  @Test
  public void test_clear_1() throws Exception {
    org.jfree.chart.block.BorderArrangement obj = new org.jfree.chart.block.BorderArrangement();
    obj.clear();
  }
  @Test
  public void test_clear_2() throws Exception {
    org.jfree.chart.block.BorderArrangement obj = new org.jfree.chart.block.BorderArrangement();
    obj.clear();
    obj.clear();
  }
}
