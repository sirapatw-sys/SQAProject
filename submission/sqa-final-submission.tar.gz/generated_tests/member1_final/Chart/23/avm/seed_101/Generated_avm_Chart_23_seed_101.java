import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_23_seed_101 {
  @Test
  public void test_isDrawLines_1() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    assertFalse(obj.isDrawLines());
  }
  @Test
  public void test_isDrawLines_2() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    assertFalse(obj.isDrawLines());
  }
  @Test
  public void test_setDrawLines_3() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(true);
    assertTrue(obj.isDrawLines());
  }
  @Test
  public void test_setDrawLines_4() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    assertFalse(obj.isDrawLines());
  }
  @Test
  public void test_setDrawLines_5() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    obj.setDrawLines(false);
    assertFalse(obj.isDrawLines());
  }
  @Test
  public void test_getGroupPaint_6() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    assertNotNull(obj.getGroupPaint());
  }
  @Test
  public void test_getGroupPaint_7() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    assertNotNull(obj.getGroupPaint());
  }
  @Test
  public void test_getGroupStroke_8() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    assertNotNull(obj.getGroupStroke());
  }
  @Test
  public void test_getGroupStroke_9() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    assertNotNull(obj.getGroupStroke());
  }
  @Test
  public void test_getObjectIcon_10() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    obj.setDrawLines(false);
    assertNotNull(obj.getObjectIcon());
  }
  @Test
  public void test_getObjectIcon_11() throws Exception {
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer obj = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    assertNotNull(obj.getObjectIcon());
  }
}
