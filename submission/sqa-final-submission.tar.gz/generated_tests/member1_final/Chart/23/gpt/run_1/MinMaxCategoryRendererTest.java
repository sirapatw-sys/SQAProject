import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertEquals;

import java.awt.Paint;
import java.awt.Stroke;

import javax.swing.Icon;

import org.jfree.chart.renderer.category.MinMaxCategoryRenderer;
import org.junit.Test;

public class MinMaxCategoryRendererTest {

    @Test
    public void testDrawLinesCanBeChangedAndReadBack() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        boolean initial = renderer.isDrawLines();
        renderer.setDrawLines(!initial);
        assertEquals(!initial, renderer.isDrawLines());

        renderer.setDrawLines(initial);
        assertEquals(initial, renderer.isDrawLines());
    }

    @Test
    public void testGroupPaintIsNonNullAndStable() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Paint paint = renderer.getGroupPaint();
        assertNotNull(paint);
        assertSame(paint, renderer.getGroupPaint());
    }

    @Test
    public void testGroupStrokeIsNonNullAndStable() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Stroke stroke = renderer.getGroupStroke();
        assertNotNull(stroke);
        assertSame(stroke, renderer.getGroupStroke());
    }

    @Test
    public void testObjectIconIsNonNullAndStable() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Icon icon = renderer.getObjectIcon();
        assertNotNull(icon);
        assertSame(icon, renderer.getObjectIcon());
    }
}
