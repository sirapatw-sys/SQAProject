import org.junit.Assert;
import org.junit.Test;
import org.jfree.chart.renderer.category.MinMaxCategoryRenderer;

public class MinMaxCategoryRendererTest {

    @Test
    public void testIsDrawLines() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        boolean initialDrawLines = renderer.isDrawLines();
        Assert.assertFalse(initialDrawLines);
    }

    @Test
    public void testSetDrawLines() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        renderer.setDrawLines(true);
        Assert.assertTrue(renderer.isDrawLines());
        renderer.setDrawLines(false);
        Assert.assertFalse(renderer.isDrawLines());
    }

    @Test
    public void testGetGroupPaint() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Assert.assertNotNull(renderer.getGroupPaint());
    }

    @Test
    public void testGetGroupStroke() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Assert.assertNotNull(renderer.getGroupStroke());
    }

    @Test
    public void testGetObjectIcon() {
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Assert.assertNotNull(renderer.getObjectIcon());
    }
}
