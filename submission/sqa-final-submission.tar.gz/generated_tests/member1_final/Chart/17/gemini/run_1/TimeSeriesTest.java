import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.Year;

public class TimeSeriesTest {

    @Test
    public void testGetDomainDescription() {
        TimeSeries series = new TimeSeries("Test Series");
        Assert.assertNull(series.getDomainDescription());
        series.setDomainDescription("Domain 1");
        Assert.assertEquals("Domain 1", series.getDomainDescription());
    }

    @Test
    public void testSetDomainDescription() {
        TimeSeries series = new TimeSeries("Test Series");
        series.setDomainDescription("New Domain");
        Assert.assertEquals("New Domain", series.getDomainDescription());
        series.setDomainDescription(null);
        Assert.assertNull(series.getDomainDescription());
    }

    @Test
    public void testGetRangeDescription() {
        TimeSeries series = new TimeSeries("Test Series");
        Assert.assertNull(series.getRangeDescription());
        series.setRangeDescription("Range 1");
        Assert.assertEquals("Range 1", series.getRangeDescription());
    }

    @Test
    public void testSetRangeDescription() {
        TimeSeries series = new TimeSeries("Test Series");
        series.setRangeDescription("New Range");
        Assert.assertEquals("New Range", series.getRangeDescription());
        series.setRangeDescription(null);
        Assert.assertNull(series.getRangeDescription());
    }

    @Test
    public void testGetItemCount() {
        TimeSeries series = new TimeSeries("Test Series");
        Assert.assertEquals(0, series.getItemCount());
        series.add(new Year(2020), 100.0);
        Assert.assertEquals(1, series.getItemCount());
        series.add(new Year(2021), 200.0);
        Assert.assertEquals(2, series.getItemCount());
    }
}
