import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.jfree.data.time.TimeSeries;
import org.junit.Test;

public class TimeSeriesTest {

    @Test
    public void domainDescriptionCanBeChangedAndCleared() {
        TimeSeries series = new TimeSeries("series");

        series.setDomainDescription("Dates");
        assertEquals("Dates", series.getDomainDescription());

        series.setDomainDescription(null);
        assertNull(series.getDomainDescription());
    }

    @Test
    public void rangeDescriptionCanBeChangedAndCleared() {
        TimeSeries series = new TimeSeries("series");

        series.setRangeDescription("Values");
        assertEquals("Values", series.getRangeDescription());

        series.setRangeDescription(null);
        assertNull(series.getRangeDescription());
    }

    @Test
    public void newSeriesHasNoItems() {
        TimeSeries series = new TimeSeries("series");

        assertEquals(0, series.getItemCount());
    }
}
