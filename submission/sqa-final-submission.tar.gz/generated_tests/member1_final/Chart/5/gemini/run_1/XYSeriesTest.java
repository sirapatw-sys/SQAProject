import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.xy.XYSeries;
import java.util.List;

public class XYSeriesTest {

    @Test
    public void testGetAutoSort() {
        XYSeries series = new XYSeries("Test Series", true, true);
        boolean autoSort = series.getAutoSort();
        Assert.assertTrue(autoSort);
    }

    @Test
    public void testGetAllowDuplicateXValues() {
        XYSeries series = new XYSeries("Test Series", true, false);
        boolean allowDuplicates = series.getAllowDuplicateXValues();
        Assert.assertFalse(allowDuplicates);
    }

    @Test
    public void testGetItemCount() {
        XYSeries series = new XYSeries("Test Series");
        Assert.assertEquals(0, series.getItemCount());
        series.add(1.0, 2.0);
        Assert.assertEquals(1, series.getItemCount());
    }

    @Test
    public void testGetItems() {
        XYSeries series = new XYSeries("Test Series");
        series.add(1.0, 5.0);
        List items = series.getItems();
        Assert.assertNotNull(items);
        Assert.assertEquals(1, items.size());
    }

    @Test
    public void testGetMaximumItemCount() {
        XYSeries series = new XYSeries("Test Series");
        int maxCount = series.getMaximumItemCount();
        Assert.assertEquals(Integer.MAX_VALUE, maxCount);
    }
}
