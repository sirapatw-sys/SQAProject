import java.util.List;

import org.jfree.data.xy.XYSeries;
import org.junit.Assert;
import org.junit.Test;

public class XYSeriesTest {

    @Test
    public void testGetAutoSortReflectsConstructorSetting() {
        XYSeries sorted = new XYSeries("sorted", true, true);
        XYSeries unsorted = new XYSeries("unsorted", false, true);

        Assert.assertTrue(sorted.getAutoSort());
        Assert.assertFalse(unsorted.getAutoSort());
    }

    @Test
    public void testGetAllowDuplicateXValuesReflectsConstructorSetting() {
        XYSeries duplicatesAllowed = new XYSeries("allowed", true, true);
        XYSeries duplicatesDisallowed = new XYSeries("disallowed", true, false);

        Assert.assertTrue(duplicatesAllowed.getAllowDuplicateXValues());
        Assert.assertFalse(duplicatesDisallowed.getAllowDuplicateXValues());
    }

    @Test
    public void testGetItemCountTracksAddedItems() {
        XYSeries series = new XYSeries("series");

        Assert.assertEquals(0, series.getItemCount());

        series.add(1.0, Integer.valueOf(10));
        series.add(2.0, Integer.valueOf(20));

        Assert.assertEquals(2, series.getItemCount());
    }

    @Test
    public void testGetItemsReturnsLiveUnmodifiableList() {
        XYSeries series = new XYSeries("series");
        List items = series.getItems();

        Assert.assertEquals(0, items.size());

        series.add(1.0, Integer.valueOf(10));

        Assert.assertEquals(1, items.size());
        try {
            items.add(null);
            Assert.fail("The items list should be unmodifiable.");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void testGetMaximumItemCountDefaultsToIntegerMaximumValue() {
        XYSeries series = new XYSeries("series");

        Assert.assertEquals(Integer.MAX_VALUE, series.getMaximumItemCount());
    }
}
