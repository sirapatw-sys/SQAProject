import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_5_seed_101 {
  @Test
  public void test_getAutoSort_1() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(0.0, 0);
    assertTrue(obj.getAutoSort());
  }
  @Test
  public void test_getAutoSort_2() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(new org.jfree.data.xy.XYDataItem(0.0, 0.0));
    assertTrue(obj.getAutoSort());
  }
  @Test
  public void test_getAutoSort_3() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.update(0, 0);
    assertTrue(obj.getAutoSort());
  }
  @Test
  public void test_getAllowDuplicateXValues_4() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(0.0, 0);
    assertTrue(obj.getAllowDuplicateXValues());
  }
  @Test
  public void test_getAllowDuplicateXValues_5() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(new org.jfree.data.xy.XYDataItem(0.0, 0.0));
    assertTrue(obj.getAllowDuplicateXValues());
  }
  @Test
  public void test_getAllowDuplicateXValues_6() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.update(0, 0);
    assertTrue(obj.getAllowDuplicateXValues());
  }
  @Test
  public void test_getItemCount_7() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(0.0, 0);
    assertEquals(2, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_8() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.update(0, 0);
    assertEquals(1, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_9() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    assertEquals(0, obj.getItemCount());
  }
  @Test
  public void test_getItems_10() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(0.0, 0);
    assertNotNull(obj.getItems());
  }
  @Test
  public void test_getItems_11() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(new org.jfree.data.xy.XYDataItem(0.0, 0.0));
    assertNotNull(obj.getItems());
  }
  @Test
  public void test_getItems_12() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.update(0, 0);
    assertNotNull(obj.getItems());
  }
  @Test
  public void test_getMaximumItemCount_13() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(0.0, 0);
    assertEquals(2147483647, obj.getMaximumItemCount());
  }
  @Test
  public void test_getMaximumItemCount_14() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.add(new org.jfree.data.xy.XYDataItem(0.0, 0.0));
    assertEquals(2147483647, obj.getMaximumItemCount());
  }
  @Test
  public void test_getMaximumItemCount_15() throws Exception {
    org.jfree.data.xy.XYSeries obj = new org.jfree.data.xy.XYSeries("sqa");
    obj.add(0, 0);
    obj.update(0, 0);
    assertEquals(2147483647, obj.getMaximumItemCount());
  }
}
