import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_22_seed_101 {
  @Test
  public void test_getRowCount_1() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    assertEquals(0, obj.getRowCount());
  }
  @Test
  public void test_getRowCount_2() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    assertEquals(0, obj.getRowCount());
  }
  @Test
  public void test_getColumnCount_3() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    assertEquals(0, obj.getColumnCount());
  }
  @Test
  public void test_getColumnCount_4() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    assertEquals(0, obj.getColumnCount());
  }
  @Test
  public void test_getObject_5() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getObject(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getObject_6() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getObject(0, 100);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getObject_7() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getObject(-10, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getRowKey_8() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getRowKey(0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getRowKey_9() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getRowKey(-10);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getRowKey_10() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    Throwable caught = null;
    try {
      obj.getRowKey(100);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getRowKeys_11() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    obj.removeObject("sqa", "sqa");
    assertNotNull(obj.getRowKeys());
  }
  @Test
  public void test_getRowKeys_12() throws Exception {
    org.jfree.data.KeyedObjects2D obj = new org.jfree.data.KeyedObjects2D();
    assertNotNull(obj.getRowKeys());
  }
}
