import org.junit.Test;
import org.junit.Assert;
import java.util.List;

public class KeyedObjects2DTest {

    @Test
    public void testGetRowCount() {
        KeyedObjects2D ko2d = new KeyedObjects2D();
        Assert.assertEquals(0, ko2d.getRowCount());
    }

    @Test
    public void testGetColumnCount() {
        KeyedObjects2D ko2d = new KeyedObjects2D();
        Assert.assertEquals(0, ko2d.getColumnCount());
    }

    @Test
    public void testGetObjectByIndices() {
        KeyedObjects2D ko2d = new KeyedObjects2D();
        // Initially empty, requesting index 0, 0 should return null gracefully or out of bounds.
        // Wait, if empty, indices 0,0 would throw IndexOutOfBoundsException on rows/columnKeys list access.
        // Let's test with a populated object or check behavior. Since we want a deterministic input,
        // let's invoke it where it returns null or handle safely. But wait, we can't easily add objects 
        // without other methods unless we use a state where rows is empty.
        // If rows is empty, ko2d.getObject(0, 0) throws IndexOutOfBoundsException.
        // Let's test empty state where it's safe or check if we can rely on what's available.
        // Actually, let's verify empty collections return 0 for count, and out of bounds throws exception,
        // but wait, can we invoke it safely? If rows is empty, `this.rows.get(row)` throws IndexOutOfBoundsException.
        // Let's check target method 6 or others, wait, we don't have public add method listed in the target or concrete API summary?
        // Wait, the concrete API summary only lists:
        // KeyedObjects2D(), getRowCount(), getColumnCount(), getObject(int, int), getRowKey(int), getRowKeys(), 
        // removeObject(...), removeRow(...), removeColumn(int), removeColumn(Comparable).
        // Since no public add method is listed in the provided API, a new KeyedObjects2D has empty rows/columns.
        // Calling getObject(0, 0) on an empty instance would throw IndexOutOfBoundsException. 
        // Therefore, we can assert that it throws IndexOutOfBoundsException when empty.
        boolean thrown = false;
        try {
            ko2d.getObject(0, 0);
        } catch (IndexOutOfBoundsException e) {
            thrown = true;
        }
        Assert.assertTrue(thrown);
    }

    @Test
    public void testGetRowKey() {
        KeyedObjects2D ko2d = new KeyedObjects2D();
        boolean thrown = false;
        try {
            ko2d.getRowKey(0);
        } catch (IndexOutOfBoundsException e) {
            thrown = true;
        }
        Assert.assertTrue(thrown);
    }

    @Test
    public void testGetRowKeys() {
        KeyedObjects2D ko2d = new KeyedObjects2D();
        List keys = ko2d.getRowKeys();
        Assert.assertNotNull(keys);
        Assert.assertTrue(keys.isEmpty());
    }
}
