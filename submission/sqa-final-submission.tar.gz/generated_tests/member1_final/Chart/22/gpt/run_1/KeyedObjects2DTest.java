import java.util.List;

import org.jfree.data.KeyedObjects2D;
import org.junit.Assert;
import org.junit.Test;

public class KeyedObjects2DTest {

    @Test
    public void testGetRowCountForNewInstanceIsZero() {
        KeyedObjects2D data = new KeyedObjects2D();

        Assert.assertEquals(0, data.getRowCount());
    }

    @Test
    public void testGetColumnCountForNewInstanceIsZero() {
        KeyedObjects2D data = new KeyedObjects2D();

        Assert.assertEquals(0, data.getColumnCount());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetObjectWithNegativeRowIndexThrowsException() {
        KeyedObjects2D data = new KeyedObjects2D();

        data.getObject(-1, 0);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetRowKeyWithNegativeIndexThrowsException() {
        KeyedObjects2D data = new KeyedObjects2D();

        data.getRowKey(-1);
    }

    @Test
    public void testGetRowKeysReturnsEmptyUnmodifiableListForNewInstance() {
        KeyedObjects2D data = new KeyedObjects2D();

        List rowKeys = data.getRowKeys();
        Assert.assertTrue(rowKeys.isEmpty());

        try {
            rowKeys.add("new-row");
            Assert.fail("The row key list should be unmodifiable.");
        }
        catch (UnsupportedOperationException expected) {
            Assert.assertTrue(data.getRowKeys().isEmpty());
        }
    }
}
