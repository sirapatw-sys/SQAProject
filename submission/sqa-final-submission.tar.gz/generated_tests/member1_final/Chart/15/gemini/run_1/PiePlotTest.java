import org.junit.Assert;
import org.junit.Test;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

public class PiePlotTest {

    @Test
    public void testGetDataset() {
        PiePlot plot = new PiePlot();
        Assert.assertNull(plot.getDataset());

        DefaultPieDataset dataset = new DefaultPieDataset();
        plot.setDataset(dataset);
        Assert.assertEquals(dataset, plot.getDataset());
    }

    @Test
    public void testGetPieIndex() {
        PiePlot plot = new PiePlot();
        Assert.assertEquals(0, plot.getPieIndex());
        
        plot.setPieIndex(5);
        Assert.assertEquals(5, plot.getPieIndex());
    }

    @Test
    public void testSetPieIndex() {
        PiePlot plot = new PiePlot();
        plot.setPieIndex(10);
        Assert.assertEquals(10, plot.getPieIndex());
    }

    @Test
    public void testGetStartAngle() {
        PiePlot plot = new PiePlot();
        // Default start angle in JFreeChart PiePlot is typically 90.0
        Assert.assertEquals(90.0, plot.getStartAngle(), 0.001);
        
        plot.setStartAngle(45.0);
        Assert.assertEquals(45.0, plot.getStartAngle(), 0.001);
    }

    @Test
    public void testSetStartAngle() {
        PiePlot plot = new PiePlot();
        plot.setStartAngle(180.0);
        Assert.assertEquals(180.0, plot.getStartAngle(), 0.001);
    }
}
