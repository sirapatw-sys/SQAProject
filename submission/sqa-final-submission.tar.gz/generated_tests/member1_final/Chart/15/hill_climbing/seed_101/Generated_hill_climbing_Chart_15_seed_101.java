import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_15_seed_101 {
  @Test
  public void test_getDataset_1() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelDistributor(new org.jfree.chart.plot.PieLabelDistributor(0));
    assertNotNull(obj.getDataset());
  }
  @Test
  public void test_getDataset_2() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    assertNull(obj.getDataset());
  }
  @Test
  public void test_getDataset_3() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    assertNotNull(obj.getDataset());
  }
  @Test
  public void test_getPieIndex_4() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelDistributor(new org.jfree.chart.plot.PieLabelDistributor(0));
    assertEquals(0, obj.getPieIndex());
  }
  @Test
  public void test_getPieIndex_5() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    assertEquals(0, obj.getPieIndex());
  }
  @Test
  public void test_getPieIndex_6() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    assertEquals(0, obj.getPieIndex());
  }
  @Test
  public void test_setPieIndex_7() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    obj.setPieIndex(0);
    assertEquals(0, obj.getPieIndex());
  }
  @Test
  public void test_setPieIndex_8() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    obj.setPieIndex(100);
    assertEquals(100, obj.getPieIndex());
  }
  @Test
  public void test_setPieIndex_9() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    obj.setPieIndex(-10);
    assertEquals(-10, obj.getPieIndex());
  }
  @Test
  public void test_getStartAngle_10() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelDistributor(new org.jfree.chart.plot.PieLabelDistributor(0));
    assertEquals(90.0, obj.getStartAngle(), 1.0e-9);
  }
  @Test
  public void test_getStartAngle_11() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
    assertEquals(90.0, obj.getStartAngle(), 1.0e-9);
  }
  @Test
  public void test_getStartAngle_12() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    assertEquals(90.0, obj.getStartAngle(), 1.0e-9);
  }
  @Test
  public void test_setStartAngle_13() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setStartAngle(0.0);
    assertEquals(0.0, obj.getStartAngle(), 1.0e-9);
  }
  @Test
  public void test_setStartAngle_14() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setStartAngle(1.0);
    assertEquals(1.0, obj.getStartAngle(), 1.0e-9);
  }
  @Test
  public void test_setStartAngle_15() throws Exception {
    org.jfree.chart.plot.PiePlot obj = new org.jfree.chart.plot.PiePlot();
    obj.setDataset(new org.jfree.data.general.DefaultPieDataset());
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setStartAngle(-10.0);
    assertEquals(-10.0, obj.getStartAngle(), 1.0e-9);
  }
}
