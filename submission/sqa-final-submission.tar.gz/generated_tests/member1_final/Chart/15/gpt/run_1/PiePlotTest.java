import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.jfree.chart.plot.PiePlot;
import org.junit.Test;

public class PiePlotTest {

    @Test
    public void getDatasetReturnsNullForDefaultPlot() {
        PiePlot plot = new PiePlot();

        assertNull(plot.getDataset());
    }

    @Test
    public void setPieIndexRetainsNegativeIndex() {
        PiePlot plot = new PiePlot();

        plot.setPieIndex(-7);

        assertEquals(-7, plot.getPieIndex());
    }

    @Test
    public void setStartAngleRetainsSpecifiedAngle() {
        PiePlot plot = new PiePlot();

        plot.setStartAngle(-270.5);

        assertEquals(-270.5, plot.getStartAngle(), 0.0);
    }
}
