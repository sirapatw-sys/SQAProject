import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.junit.Assert;
import org.junit.Test;

public class DefaultBoxAndWhiskerCategoryDatasetTest {

    private static class MedianProvidingDataset
            extends DefaultBoxAndWhiskerCategoryDataset {

        private int requestedRow;
        private int requestedColumn;

        @Override
        public Number getMedianValue(int row, int column) {
            this.requestedRow = row;
            this.requestedColumn = column;
            return Integer.valueOf(17);
        }
    }

    @Test
    public void getValueReturnsMedianValueForRequestedCell() {
        MedianProvidingDataset dataset = new MedianProvidingDataset();

        Number value = dataset.getValue(-3, 4);

        Assert.assertEquals(Integer.valueOf(17), value);
        Assert.assertEquals(-3, dataset.requestedRow);
        Assert.assertEquals(4, dataset.requestedColumn);
    }
}
