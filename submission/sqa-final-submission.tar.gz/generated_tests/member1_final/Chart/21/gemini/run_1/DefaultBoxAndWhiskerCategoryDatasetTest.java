import org.junit.Test;
import org.junit.Assert;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerItem;
import java.util.ArrayList;

public class DefaultBoxAndWhiskerCategoryDatasetTest {

    @Test
    public void testGetItem() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, new ArrayList());
        dataset.add(item, "Row 1", "Column 1");
        
        BoxAndWhiskerItem retrieved = dataset.getItem(0, 0);
        Assert.assertNotNull(retrieved);
        Assert.assertEquals(1.0, retrieved.getMean());
    }

    @Test
    public void testGetValue () {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, new ArrayList());
        dataset.add(item, "Row 1", "Column 1");
        
        Number value = dataset.getValue(0, 0);
        Assert.assertEquals(2.0, value);
    }

    @Test
    public void testGetMeanValue() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, new ArrayList());
        dataset.add(item, "Row 1", "Column 1");
        
        Number mean = dataset.getMeanValue(0, 0);
        Assert.assertEquals(1.0, mean);
    }

    @Test
    public void testGetMedianValue() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, new ArrayList());
        dataset.add(item, "Row 1", "Column 1");
        
        Number median = dataset.getMedianValue(0, 0);
        Assert.assertEquals(2.0, median);
    }

    @Test
    public void testGetQ1Value() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, new ArrayList());
        dataset.add(item, "Row 1", "Column 1");
        
        Number q1 = dataset.getQ1Value(0, 0);
        Assert.assertEquals(3.0, q1);
    }
}
