import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_21_seed_101 {
  @Test
  public void test_getItem_1() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getItem(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getItem_2() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getItem(10, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getItem_3() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getItem(0, 1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_4() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getValue(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_5() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getValue(0, -10);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_6() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getValue(-100, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMeanValue_7() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMeanValue(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMeanValue_8() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMeanValue(-1, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMeanValue_9() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMeanValue(100, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMedianValue_10() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMedianValue(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMedianValue_11() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMedianValue(-100, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getMedianValue_12() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getMedianValue(0, 1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getQ1Value_13() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getQ1Value(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getQ1Value_14() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getQ1Value(-1, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getQ1Value_15() throws Exception {
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset obj = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    Throwable caught = null;
    try {
      obj.getQ1Value(0, -1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
}
