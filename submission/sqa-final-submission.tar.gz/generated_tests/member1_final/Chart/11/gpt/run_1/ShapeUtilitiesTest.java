import java.awt.Shape;
import java.awt.geom.PathIterator;

import org.jfree.chart.util.ShapeUtilities;
import org.junit.Assert;
import org.junit.Test;

public class ShapeUtilitiesTest {

    private static void assertClosedPath(Shape shape, float[][] expectedPoints) {
        PathIterator iterator = shape.getPathIterator(null);
        float[] coordinates = new float[6];

        for (int i = 0; i < expectedPoints.length; i++) {
            int expectedSegment = (i == 0)
                    ? PathIterator.SEG_MOVETO : PathIterator.SEG_LINETO;
            Assert.assertFalse("Missing path segment " + i, iterator.isDone());
            Assert.assertEquals(expectedSegment, iterator.currentSegment(coordinates));
            Assert.assertEquals(expectedPoints[i][0], coordinates[0], 0.00001f);
            Assert.assertEquals(expectedPoints[i][1], coordinates[1], 0.00001f);
            iterator.next();
        }

        Assert.assertFalse("Missing close segment", iterator.isDone());
        Assert.assertEquals(PathIterator.SEG_CLOSE, iterator.currentSegment(coordinates));
        iterator.next();
        Assert.assertTrue("Unexpected additional path segments", iterator.isDone());
    }

    @Test
    public void createDiagonalCrossBuildsExpectedClosedTwelvePointPath() {
        float root2 = (float) Math.sqrt(2.0);
        Shape shape = ShapeUtilities.createDiagonalCross(3.0f, 1.0f);

        assertClosedPath(shape, new float[][] {
            {-4.0f, -2.0f},
            {-2.0f, -4.0f},
            {0.0f, -root2},
            {2.0f, -4.0f},
            {4.0f, -2.0f},
            {root2, 0.0f},
            {4.0f, 2.0f},
            {2.0f, 4.0f},
            {0.0f, root2},
            {-2.0f, 4.0f},
            {-4.0f, 2.0f},
            {-root2, 0.0f}
        });
    }

    @Test
    public void createRegularCrossBuildsExpectedClosedTwelvePointPath() {
        Shape shape = ShapeUtilities.createRegularCross(3.0f, 1.0f);

        assertClosedPath(shape, new float[][] {
            {-3.0f, 1.0f},
            {-1.0f, 1.0f},
            {-1.0f, 3.0f},
            {1.0f, 3.0f},
            {1.0f, 1.0f},
            {3.0f, 1.0f},
            {3.0f, -1.0f},
            {1.0f, -1.0f},
            {1.0f, -3.0f},
            {-1.0f, -3.0f},
            {-1.0f, -1.0f},
            {-3.0f, -1.0f}
        });
    }

    @Test
    public void createDiamondBuildsExpectedClosedDiamondPath() {
        Shape shape = ShapeUtilities.createDiamond(2.0f);

        assertClosedPath(shape, new float[][] {
            {0.0f, -2.0f},
            {2.0f, 0.0f},
            {0.0f, 2.0f},
            {-2.0f, 0.0f}
        });
    }

    @Test
    public void createUpTriangleBuildsExpectedClosedUpwardTrianglePath() {
        Shape shape = ShapeUtilities.createUpTriangle(2.0f);

        assertClosedPath(shape, new float[][] {
            {0.0f, -2.0f},
            {2.0f, 2.0f},
            {-2.0f, 2.0f}
        });
    }

    @Test
    public void createDownTriangleBuildsExpectedClosedDownwardTrianglePath() {
        Shape shape = ShapeUtilities.createDownTriangle(2.0f);

        assertClosedPath(shape, new float[][] {
            {0.0f, 2.0f},
            {2.0f, -2.0f},
            {-2.0f, -2.0f}
        });
    }
}
