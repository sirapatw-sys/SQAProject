import org.junit.Test;
import org.junit.Assert;
import java.awt.Shape;

public class ShapeUtilitiesTest {

    @Test
    public void testCreateDiagonalCross() {
        Shape shape = ShapeUtilities.createDiagonalCross(5.0f, 1.0f);
        Assert.assertNotNull(shape);
    }

    @Test
    public void testCreateRegularCross() {
        Shape shape = ShapeUtilities.createRegularCross(5.0f, 1.0f);
        Assert.assertNotNull(shape);
    }

    @Test
    public void testCreateDiamond() {
        Shape shape = ShapeUtilities.createDiamond(4.0f);
        Assert.assertNotNull(shape);
    }

    @Test
    public void testCreateUpTriangle() {
        Shape shape = ShapeUtilities.createUpTriangle(4.0f);
        Assert.assertNotNull(shape);
    }

    @Test
    public void testCreateDownTriangle() {
        Shape shape = ShapeUtilities.createDownTriangle(4.0f);
        Assert.assertNotNull(shape);
    }
}
