import static org.junit.Assert.assertEquals;

import org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator;
import org.junit.Test;

public class StandardToolTipTagFragmentGeneratorTest {

    @Test
    public void generateToolTipFragmentFormatsPlainTooltipAsHtmlAttributes() {
        StandardToolTipTagFragmentGenerator generator =
                new StandardToolTipTagFragmentGenerator();

        assertEquals(" title=\"Quarterly Sales\" alt=\"\"",
                generator.generateToolTipFragment("Quarterly Sales"));
    }
}
