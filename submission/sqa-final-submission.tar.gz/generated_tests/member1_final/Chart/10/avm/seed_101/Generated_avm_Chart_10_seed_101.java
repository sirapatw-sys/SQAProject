import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_10_seed_101 {
  @Test
  public void test_generateToolTipFragment_1() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"\" alt=\"\"", obj.generateToolTipFragment(""));
  }
  @Test
  public void test_generateToolTipFragment_2() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"a\" alt=\"\"", obj.generateToolTipFragment("a"));
  }
  @Test
  public void test_generateToolTipFragment_3() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"0\" alt=\"\"", obj.generateToolTipFragment("0"));
  }
}
