import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_10_seed_101 {
  @Test
  public void test_generateToolTipFragment_1() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"\" alt=\"\"", obj.generateToolTipFragment(""));
  }
  @Test
  public void test_generateToolTipFragment_2() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"test\" alt=\"\"", obj.generateToolTipFragment("test"));
  }
  @Test
  public void test_generateToolTipFragment_3() throws Exception {
    org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator obj = new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator();
    assertEquals(" title=\"-1\" alt=\"\"", obj.generateToolTipFragment("-1"));
  }
}
