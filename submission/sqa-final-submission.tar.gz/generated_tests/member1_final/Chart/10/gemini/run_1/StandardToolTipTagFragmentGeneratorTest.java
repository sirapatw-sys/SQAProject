import org.junit.Test;
import org.junit.Assert;
import org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator;

public class StandardToolTipTagFragmentGeneratorTest {

    @Test
    public void testGenerateToolTipFragment() {
        StandardToolTipTagFragmentGenerator generator = new StandardToolTipTagFragmentGenerator();
        String result = generator.generateToolTipFragment("Test Tooltip");
        Assert.assertEquals(" title=\"Test Tooltip\" alt=\"\"", result);
    }
}
