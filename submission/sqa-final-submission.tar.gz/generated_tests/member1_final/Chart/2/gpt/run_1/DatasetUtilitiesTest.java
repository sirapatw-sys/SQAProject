import static org.junit.Assert.assertEquals;

import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.pie.DefaultPieDataset;
import org.junit.Test;

public class DatasetUtilitiesTest {

    @Test
    public void calculatePieDatasetTotalIgnoresNullZeroAndNegativeValues() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("positive-one", Double.valueOf(2.5));
        dataset.setValue("positive-two", Double.valueOf(4.0));
        dataset.setValue("zero", Double.valueOf(0.0));
        dataset.setValue("negative", Double.valueOf(-3.0));
        dataset.setValue("null", null);

        assertEquals(6.5, DatasetUtilities.calculatePieDatasetTotal(dataset),
                0.0000001);
    }
}
