import org.junit.Test;
import org.junit.Assert;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class DatasetUtilitiesTest {

    @Test
    public void testCalculatePieDatasetTotal() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("A", 10.0);
        dataset.setValue("B", 20.0);
        dataset.setValue("C", -5.0); // Should be ignored
        
        double total = DatasetUtilities.calculatePieDatasetTotal(dataset);
        Assert.assertEquals(30.0, total, 0.0001);
    }

    @Test
    public void testCreatePieDatasetForRow() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");
        dataset.addValue(3.0, "Row2", "Col1");

        PieDataset pieDataset = DatasetUtilities.createPieDatasetForRow(dataset, "Row1");
        Assert.assertEquals(2, pieDataset.getItemCount());
        Assert.assertEquals(1.0, pieDataset.getValue("Col1").doubleValue(), 0.0001);
        Assert.assertEquals(2.0, pieDataset.getValue("Col2").doubleValue(), 0.0001);
    }

    @Test
    public void testCreatePieDatasetForColumn() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(3.0, "Row2", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");

        PieDataset pieDataset = DatasetUtilities.createPieDatasetForColumn(dataset, "Col1");
        Assert.assertEquals(2, pieDataset.getItemCount());
        Assert.assertEquals(1.0, pieDataset.getValue("Row1").doubleValue(), 0.0001);
        Assert.assertEquals(3.0, pieDataset.getValue("Row2").doubleValue(), 0.0001);
    }

    @Test
    public void testCreateConsolidatedPieDataset() {
        DefaultPieDataset source = new DefaultPieDataset();
        source.setValue("A", 80.0);
        source.setValue("B", 10.0);
        source.setValue("C", 10.0);

        PieDataset result = DatasetUtilities.createConsolidatedPieDataset(source, "Other", 0.15, 2);
        Assert.assertNotNull(result);
        Assert.assertEquals(80.0, result.getValue("A").doubleValue(), 0.0001);
        Assert.assertEquals(20.0, result.getValue("Other").doubleValue(), 0.0001);
    }
}
