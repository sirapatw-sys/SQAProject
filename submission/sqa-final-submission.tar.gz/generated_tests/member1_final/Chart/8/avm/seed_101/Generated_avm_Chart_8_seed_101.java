import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_8_seed_101 {
  @Test
  public void test_getYear_1() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    assertNotNull(obj.getYear());
  }
  @Test
  public void test_getYear_2() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    obj.peg(java.util.Calendar.getInstance());
    assertNotNull(obj.getYear());
  }
  @Test
  public void test_getYearValue_3() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    assertEquals(2026, obj.getYearValue());
  }
  @Test
  public void test_getYearValue_4() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    obj.peg(java.util.Calendar.getInstance());
    assertEquals(2026, obj.getYearValue());
  }
  @Test
  public void test_getWeek_5() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    assertEquals(39, obj.getWeek());
  }
  @Test
  public void test_getWeek_6() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    obj.peg(java.util.Calendar.getInstance());
    assertEquals(39, obj.getWeek());
  }
  @Test
  public void test_getFirstMillisecond_7() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    assertEquals(1789887600000L, obj.getFirstMillisecond());
  }
  @Test
  public void test_getFirstMillisecond_8() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    obj.peg(java.util.Calendar.getInstance());
    assertEquals(1789887600000L, obj.getFirstMillisecond());
  }
  @Test
  public void test_getLastMillisecond_9() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    assertEquals(1790492399999L, obj.getLastMillisecond());
  }
  @Test
  public void test_getLastMillisecond_10() throws Exception {
    org.jfree.data.time.Week obj = new org.jfree.data.time.Week();
    obj.peg(java.util.Calendar.getInstance());
    assertEquals(1790492399999L, obj.getLastMillisecond());
  }
}
