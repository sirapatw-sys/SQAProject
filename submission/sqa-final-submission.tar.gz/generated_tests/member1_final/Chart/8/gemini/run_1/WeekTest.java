import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.time.Week;
import org.jfree.data.time.Year;

public class WeekTest {

    @Test
    public void testGetYear() {
        Week week = new Week(7, 2023);
        Year year = week.getYear();
        Assert.assertNotNull(year);
        Assert.assertEquals(2023, year.getYear());
    }

    @Test
    public void testGetYearValue() {
        Week week = new Week(15, 2022);
        int yearValue = week.getYearValue();
        Assert.assertEquals(2022, yearValue);
    }

    @Test
    public void testGetWeek() {
        Week week = new Week(25, 2021);
        int weekValue = week.getWeek();
        Assert.assertEquals(25, weekValue);
    }

    @Test
    public void testGetFirstMillisecond() {
        Week week = new Week(1, 2020);
        long firstMillisecond = week.getFirstMillisecond();
        // Ensure millisecond computation happens and returns a valid timestamp
        Assert.assertTrue(firstMillisecond > 0L);
    }

    @Test
    public void testGetLastMillisecond() {
        Week week = new Week(1, 2020);
        long lastMillisecond = week.getLastMillisecond();
        // Ensure last millisecond computation happens and returns a valid timestamp greater than or equal to first millisecond
        Assert.assertTrue(lastMillisecond >= week.getFirstMillisecond());
    }
}
