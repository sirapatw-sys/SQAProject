import static org.junit.Assert.assertEquals;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.jfree.data.time.Week;
import org.junit.Test;

public class WeekTest {

    private Calendar createIsoUtcCalendar() {
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setMinimalDaysInFirstWeek(4);
        return calendar;
    }

    @Test
    public void getYearReturnsYearRepresentingWeekYear() {
        Week week = new Week(52, 2018);

        assertEquals(2018, week.getYear().getYear());
    }

    @Test
    public void getYearValueReturnsConstructorYear() {
        Week week = new Week(1, 2000);

        assertEquals(2000, week.getYearValue());
    }

    @Test
    public void getWeekReturnsConstructorWeekNumber() {
        Week week = new Week(53, 2015);

        assertEquals(53, week.getWeek());
    }

    @Test
    public void getFirstMillisecondReturnsStartOfConfiguredWeek() {
        Week week = new Week(2, 2015);
        week.peg(createIsoUtcCalendar());

        Calendar expected = createIsoUtcCalendar();
        expected.clear();
        expected.set(2015, Calendar.JANUARY, 5, 0, 0, 0);

        assertEquals(expected.getTimeInMillis(), week.getFirstMillisecond());
    }

    @Test
    public void getLastMillisecondReturnsFinalMillisecondOfConfiguredWeek() {
        Week week = new Week(2, 2015);
        week.peg(createIsoUtcCalendar());

        Calendar expected = createIsoUtcCalendar();
        expected.clear();
        expected.set(2015, Calendar.JANUARY, 11, 23, 59, 59);
        expected.set(Calendar.MILLISECOND, 999);

        assertEquals(expected.getTimeInMillis(), week.getLastMillisecond());
    }
}
