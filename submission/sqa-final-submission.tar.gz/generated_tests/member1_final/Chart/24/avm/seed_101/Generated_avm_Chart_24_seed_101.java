import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_24_seed_101 {
  @Test
  public void test_getLowerBound_1() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertEquals(0.0, obj.getLowerBound(), 1.0e-9);
  }
  @Test
  public void test_getUpperBound_2() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertEquals(1.0, obj.getUpperBound(), 1.0e-9);
  }
  @Test
  public void test_getPaint_3() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertNotNull(obj.getPaint(0.0));
  }
  @Test
  public void test_getPaint_4() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertNotNull(obj.getPaint(1.0));
  }
  @Test
  public void test_getPaint_5() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertNotNull(obj.getPaint(-1.0));
  }
  @Test
  public void test_clone_6() throws Exception {
    org.jfree.chart.renderer.GrayPaintScale obj = new org.jfree.chart.renderer.GrayPaintScale();
    assertNotNull(obj.clone());
  }
}
