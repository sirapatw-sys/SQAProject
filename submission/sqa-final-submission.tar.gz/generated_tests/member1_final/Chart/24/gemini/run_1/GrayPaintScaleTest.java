import org.junit.Test;
import org.junit.Assert;
import java.awt.Color;
import java.awt.Paint;
import org.jfree.chart.renderer.GrayPaintScale;

public class GrayPaintScaleTest {

    @Test
    public void testGetLowerBound() {
        GrayPaintScale scale = new GrayPaintScale(1.0, 10.0);
        Assert.assertEquals(1.0, scale.getLowerBound(), 0.0001);
    }

    @Test
    public void testGetUpperBound() {
        GrayPaintScale scale = new GrayPaintScale(1.0, 10.0);
        Assert.assertEquals(10.0, scale.getUpperBound(), 0.0001);
    }

    @Test
    public void testGetPaint() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
        Paint paint = scale.getPaint(50.0);
        Assert.assertEquals(new Color(128, 128, 128), paint);
    }

    @Test
    public void testClone() throws Exception {
        GrayPaintScale scale = new GrayPaintScale(2.0, 8.0);
        Object clone = scale.clone();
        Assert.assertTrue(clone instanceof GrayPaintScale);
        GrayPaintScale clonedScale = (GrayPaintScale) clone;
        Assert.assertEquals(scale.getLowerBound(), clonedScale.getLowerBound(), 0.0001);
        Assert.assertEquals(scale.getUpperBound(), clonedScale.getUpperBound(), 0.0001);
    }
}
