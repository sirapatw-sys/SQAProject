import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import java.awt.Color;

import org.jfree.chart.renderer.GrayPaintScale;
import org.junit.Test;

public class GrayPaintScaleTest {

    @Test
    public void getLowerBoundReturnsConfiguredLowerBound() {
        GrayPaintScale scale = new GrayPaintScale(-2.5, 7.5);

        assertEquals(-2.5, scale.getLowerBound(), 0.0);
    }

    @Test
    public void getUpperBoundReturnsConfiguredUpperBound() {
        GrayPaintScale scale = new GrayPaintScale(-2.5, 7.5);

        assertEquals(7.5, scale.getUpperBound(), 0.0);
    }

    @Test
    public void getPaintClampsValuesAndMapsRangeToGrayLevels() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);

        assertEquals(new Color(0, 0, 0), scale.getPaint(-10.0));
        assertEquals(new Color(0, 0, 0), scale.getPaint(0.0));
        assertEquals(new Color(127, 127, 127), scale.getPaint(50.0));
        assertEquals(new Color(255, 255, 255), scale.getPaint(100.0));
        assertEquals(new Color(255, 255, 255), scale.getPaint(150.0));
    }

    @Test
    public void cloneCreatesDistinctScaleWithSameBoundsAndPaintMapping()
            throws CloneNotSupportedException {
        GrayPaintScale original = new GrayPaintScale(-10.0, 30.0);

        GrayPaintScale copy = (GrayPaintScale) original.clone();

        assertNotSame(original, copy);
        assertEquals(-10.0, copy.getLowerBound(), 0.0);
        assertEquals(30.0, copy.getUpperBound(), 0.0);
        assertEquals(original.getPaint(10.0), copy.getPaint(10.0));
    }
}
