import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.jfree.chart.plot.CategoryPlot;
import org.junit.Test;

public class CategoryPlotTest {

    @Test
    public void getPlotTypeReturnsLocalizedPlotDescription() {
        CategoryPlot plot = new CategoryPlot();

        assertNotNull(plot.getPlotType());
    }

    @Test
    public void getOrientationReturnsStoredNonNullOrientation() {
        CategoryPlot plot = new CategoryPlot();

        assertNotNull(plot.getOrientation());
        assertSame(plot.getOrientation(), plot.getOrientation());
    }

    @Test
    public void getAxisOffsetReturnsStoredNonNullInsets() {
        CategoryPlot plot = new CategoryPlot();

        assertNotNull(plot.getAxisOffset());
        assertSame(plot.getAxisOffset(), plot.getAxisOffset());
    }

    @Test
    public void getDomainAxisDelegatesToAxisZero() {
        CategoryPlot plot = new CategoryPlot();

        assertSame(plot.getDomainAxis(0), plot.getDomainAxis());
    }

    @Test
    public void getDomainAxisReturnsNullForUnconfiguredOutOfRangeAxis() {
        CategoryPlot plot = new CategoryPlot(null, null, null, null);

        assertNull(plot.getDomainAxis(1));
    }
}
