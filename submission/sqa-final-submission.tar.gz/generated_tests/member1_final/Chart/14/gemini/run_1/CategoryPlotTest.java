import org.junit.Assert;
import org.junit.Test;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.axis.CategoryAxis;

public class CategoryPlotTest {

    @Test
    public void testGetPlotType() {
        CategoryPlot plot = new CategoryPlot();
        String plotType = plot.getPlotType();
        Assert.assertNotNull(plotType);
    }

    @Test
    public void testGetOrientation() {
        CategoryPlot plot = new CategoryPlot();
        PlotOrientation orientation = plot.getOrientation();
        Assert.assertNotNull(orientation);
    }

    @Test
    public void testGetAxisOffset() {
        CategoryPlot plot = new CategoryPlot();
        RectangleInsets offset = plot.getAxisOffset();
        Assert.assertNotNull(offset);
    }

    @Test
    public void testGetDomainAxis() {
        CategoryPlot plot = new CategoryPlot();
        CategoryAxis axis = plot.getDomainAxis();
        // Default constructor sets up a default domain axis at index 0
        Assert.assertNotNull(axis);
    }

    @Test
    public void testGetDomainAxisWithIndex() {
        CategoryPlot plot = new CategoryPlot();
        CategoryAxis axis = plot.getDomainAxis(0);
        Assert.assertNotNull(axis);

        // Out of bounds index should return null when there is no parent plot
        CategoryAxis outOfBoundsAxis = plot.getDomainAxis(99);
        Assert.assertNull(outOfBoundsAxis);
    }
}
