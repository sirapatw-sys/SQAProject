import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_25_seed_101 {
  @Test
  public void test_getErrorIndicatorPaint_1() throws Exception {
    org.jfree.chart.renderer.category.StatisticalBarRenderer obj = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    assertNotNull(obj.getErrorIndicatorPaint());
  }
  @Test
  public void test_getErrorIndicatorStroke_2() throws Exception {
    org.jfree.chart.renderer.category.StatisticalBarRenderer obj = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    assertNotNull(obj.getErrorIndicatorStroke());
  }
}
