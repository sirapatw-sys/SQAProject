import org.jfree.chart.renderer.category.StatisticalBarRenderer;
import org.junit.Assert;
import org.junit.Test;

public class StatisticalBarRendererTest {

    @Test
    public void getErrorIndicatorPaintReturnsTheStoredPaintConsistently() {
        StatisticalBarRenderer renderer = new StatisticalBarRenderer();

        Object first = renderer.getErrorIndicatorPaint();
        Object second = renderer.getErrorIndicatorPaint();

        Assert.assertSame(first, second);
    }

    @Test
    public void getErrorIndicatorStrokeReturnsTheStoredStrokeConsistently() {
        StatisticalBarRenderer renderer = new StatisticalBarRenderer();

        Object first = renderer.getErrorIndicatorStroke();
        Object second = renderer.getErrorIndicatorStroke();

        Assert.assertSame(first, second);
    }
}
