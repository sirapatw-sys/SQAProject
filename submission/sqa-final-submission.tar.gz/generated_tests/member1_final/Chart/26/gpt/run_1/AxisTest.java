import java.awt.Font;

import org.jfree.chart.axis.NumberAxis;
import org.junit.Assert;
import org.junit.Test;

public class AxisTest {

    @Test
    public void testIsVisibleReflectsCurrentVisibilityState() {
        NumberAxis axis = new NumberAxis();

        axis.setVisible(false);
        Assert.assertFalse(axis.isVisible());

        axis.setVisible(true);
        Assert.assertTrue(axis.isVisible());
    }

    @Test
    public void testSetVisibleChangesVisibility() {
        NumberAxis axis = new NumberAxis();

        axis.setVisible(false);
        Assert.assertFalse(axis.isVisible());

        axis.setVisible(true);
        Assert.assertTrue(axis.isVisible());
    }

    @Test
    public void testGetLabelReturnsAssignedLabelIncludingNull() {
        NumberAxis axis = new NumberAxis();

        axis.setLabel("Revenue");
        Assert.assertEquals("Revenue", axis.getLabel());

        axis.setLabel(null);
        Assert.assertNull(axis.getLabel());
    }

    @Test
    public void testSetLabelReplacesExistingLabelAndAllowsNull() {
        NumberAxis axis = new NumberAxis();

        axis.setLabel("First");
        Assert.assertEquals("First", axis.getLabel());

        axis.setLabel("Second");
        Assert.assertEquals("Second", axis.getLabel());

        axis.setLabel(null);
        Assert.assertNull(axis.getLabel());
    }

    @Test
    public void testGetLabelFontReturnsFontAssignedToAxis() {
        NumberAxis axis = new NumberAxis();
        Font font = new Font("Dialog", Font.BOLD | Font.ITALIC, 17);

        axis.setLabelFont(font);

        Assert.assertEquals(font, axis.getLabelFont());
    }
}
