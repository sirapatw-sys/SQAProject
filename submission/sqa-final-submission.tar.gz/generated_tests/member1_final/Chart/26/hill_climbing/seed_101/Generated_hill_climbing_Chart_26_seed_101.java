import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_26_seed_101 {
  @Test
  public void test_isVisible_1() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    assertTrue(obj.isVisible());
  }
  @Test
  public void test_isVisible_2() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setTickLabelFont(java.awt.Font.decode("sqa"));
    assertTrue(obj.isVisible());
  }
  @Test
  public void test_isVisible_3() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setPlot(new org.jfree.chart.plot.CategoryPlot());
    assertTrue(obj.isVisible());
  }
  @Test
  public void test_setVisible_4() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    obj.setVisible(false);
    assertFalse(obj.isVisible());
  }
  @Test
  public void test_setVisible_5() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    obj.setVisible(true);
    assertTrue(obj.isVisible());
  }
  @Test
  public void test_setVisible_6() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setTickLabelFont(java.awt.Font.decode("sqa"));
    obj.setVisible(false);
    assertFalse(obj.isVisible());
  }
  @Test
  public void test_getLabel_7() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    assertNull(obj.getLabel());
  }
  @Test
  public void test_getLabel_8() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setTickLabelFont(java.awt.Font.decode("sqa"));
    assertNull(obj.getLabel());
  }
  @Test
  public void test_getLabel_9() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setPlot(new org.jfree.chart.plot.CategoryPlot());
    assertNull(obj.getLabel());
  }
  @Test
  public void test_setLabel_10() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    obj.setLabel("");
    assertEquals("", obj.getLabel());
  }
  @Test
  public void test_setLabel_11() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    obj.setLabel("0");
    assertEquals("0", obj.getLabel());
  }
  @Test
  public void test_setLabel_12() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    obj.setLabel("null");
    assertEquals("null", obj.getLabel());
  }
  @Test
  public void test_getLabelFont_13() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setTickLabelFont(java.awt.Font.decode("sqa"));
    assertNotNull(obj.getLabelFont());
  }
  @Test
  public void test_getLabelFont_14() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setLabelInsets(org.jfree.chart.util.RectangleInsets.ZERO_INSETS);
    assertNotNull(obj.getLabelFont());
  }
  @Test
  public void test_getLabelFont_15() throws Exception {
    org.jfree.chart.axis.Axis obj = new org.jfree.chart.axis.CategoryAxis();
    obj.setLabelFont(java.awt.Font.decode("sqa"));
    obj.setPlot(new org.jfree.chart.plot.CategoryPlot());
    assertNotNull(obj.getLabelFont());
  }
}
