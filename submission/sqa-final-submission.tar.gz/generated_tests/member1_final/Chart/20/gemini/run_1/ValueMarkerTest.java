import org.junit.Test;
import org.junit.Assert;
import org.jfree.chart.plot.ValueMarker;

public class ValueMarkerTest {

    @Test
    public void testGetValue() {
        ValueMarker marker = new ValueMarker(150.5);
        Assert.assertEquals(150.5, marker.getValue(), 0.0001);
    }

    @Test
    public void testSetValue() {
        ValueMarker marker = new ValueMarker(10.0);
        marker.setValue(25.5);
        Assert.assertEquals(25.5, marker.getValue(), 0.0001);
    }
}
