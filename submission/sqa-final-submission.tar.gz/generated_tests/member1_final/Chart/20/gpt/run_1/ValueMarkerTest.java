import org.jfree.chart.plot.ValueMarker;
import org.junit.Assert;
import org.junit.Test;

public class ValueMarkerTest {

    @Test
    public void getValueReturnsMostRecentlyAssignedValue() {
        ValueMarker marker = new ValueMarker(0.0);

        marker.setValue(42.75);

        Assert.assertEquals(42.75, marker.getValue(), 0.0);
    }

    @Test
    public void setValuePreservesNegativeZero() {
        ValueMarker marker = new ValueMarker(1.0);

        marker.setValue(-0.0);

        Assert.assertEquals(
                Double.doubleToLongBits(-0.0),
                Double.doubleToLongBits(marker.getValue()));
    }
}
