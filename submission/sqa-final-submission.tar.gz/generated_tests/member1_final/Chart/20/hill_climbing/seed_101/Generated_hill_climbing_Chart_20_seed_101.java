import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_20_seed_101 {
  @Test
  public void test_getValue_1() throws Exception {
    org.jfree.chart.plot.ValueMarker obj = new org.jfree.chart.plot.ValueMarker(0.0);
    obj.setValue(0.0);
    assertEquals(0.0, obj.getValue(), 1.0e-9);
  }
  @Test
  public void test_getValue_2() throws Exception {
    org.jfree.chart.plot.ValueMarker obj = new org.jfree.chart.plot.ValueMarker(0.0);
    assertEquals(0.0, obj.getValue(), 1.0e-9);
  }
  @Test
  public void test_setValue_3() throws Exception {
    org.jfree.chart.plot.ValueMarker obj = new org.jfree.chart.plot.ValueMarker(0.0);
    obj.setValue(0.0);
    assertEquals(0.0, obj.getValue(), 1.0e-9);
  }
  @Test
  public void test_setValue_4() throws Exception {
    org.jfree.chart.plot.ValueMarker obj = new org.jfree.chart.plot.ValueMarker(0.0);
    obj.setValue(10.0);
    assertEquals(10.0, obj.getValue(), 1.0e-9);
  }
  @Test
  public void test_setValue_5() throws Exception {
    org.jfree.chart.plot.ValueMarker obj = new org.jfree.chart.plot.ValueMarker(0.0);
    obj.setValue(-100.0);
    assertEquals(-100.0, obj.getValue(), 1.0e-9);
  }
}
