import java.util.List;

import org.jfree.data.category.DefaultIntervalCategoryDataset;
import org.junit.Assert;
import org.junit.Test;

public class DefaultIntervalCategoryDatasetTest {

    private DefaultIntervalCategoryDataset createDataset() {
        Comparable[] seriesKeys = new Comparable[] {"Series A", "Series B"};
        Comparable[] categoryKeys = new Comparable[] {"Category 1", "Category 2", "Category 3"};
        Number[][] startData = new Number[][] {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0}
        };
        Number[][] endData = new Number[][] {
            {10.0, 20.0, 30.0},
            {40.0, 50.0, 60.0}
        };
        return new DefaultIntervalCategoryDataset(
                seriesKeys, categoryKeys, startData, endData);
    }

    @Test
    public void getSeriesCountReturnsNumberOfDataRows() {
        DefaultIntervalCategoryDataset dataset = createDataset();

        Assert.assertEquals(2, dataset.getSeriesCount());
    }

    @Test
    public void getSeriesKeyReturnsKeyAndRejectsOutOfRangeIndexes() {
        DefaultIntervalCategoryDataset dataset = createDataset();

        Assert.assertEquals("Series B", dataset.getSeriesKey(1));

        try {
            dataset.getSeriesKey(-1);
            Assert.fail("Expected IllegalArgumentException for a negative series index.");
        }
        catch (IllegalArgumentException expected) {
            Assert.assertEquals("No such series : -1", expected.getMessage());
        }

        try {
            dataset.getSeriesKey(2);
            Assert.fail("Expected IllegalArgumentException for an index equal to the series count.");
        }
        catch (IllegalArgumentException expected) {
            Assert.assertEquals("No such series : 2", expected.getMessage());
        }
    }

    @Test
    public void getCategoryCountReturnsNumberOfValuesInFirstSeries() {
        DefaultIntervalCategoryDataset dataset = createDataset();

        Assert.assertEquals(3, dataset.getCategoryCount());
    }

    @Test
    public void getColumnKeysReturnsOrderedUnmodifiableCategoryKeys() {
        DefaultIntervalCategoryDataset dataset = createDataset();

        List keys = dataset.getColumnKeys();
        Assert.assertEquals(3, keys.size());
        Assert.assertEquals("Category 1", keys.get(0));
        Assert.assertEquals("Category 2", keys.get(1));
        Assert.assertEquals("Category 3", keys.get(2));

        try {
            keys.add("Another Category");
            Assert.fail("Column keys list should be unmodifiable.");
        }
        catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void getValueReturnsEndValueForSeriesAndCategory() {
        DefaultIntervalCategoryDataset dataset = createDataset();

        Assert.assertEquals(10.0, dataset.getValue(0, 0).doubleValue(), 0.0);
        Assert.assertEquals(60.0, dataset.getValue(1, 2).doubleValue(), 0.0);
    }
}
