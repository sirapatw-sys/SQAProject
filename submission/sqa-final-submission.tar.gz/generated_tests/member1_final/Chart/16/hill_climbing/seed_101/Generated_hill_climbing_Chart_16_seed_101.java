import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_16_seed_101 {
  @Test
  public void test_getSeriesCount_1() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    assertEquals(0, obj.getSeriesCount());
  }
  @Test
  public void test_getSeriesKey_2() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getSeriesKey(-10);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_getSeriesKey_3() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getSeriesKey(-110);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_getSeriesKey_4() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getSeriesKey(-11);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_getCategoryCount_5() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    assertEquals(0, obj.getCategoryCount());
  }
  @Test
  public void test_getColumnKeys_6() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    assertNotNull(obj.getColumnKeys());
  }
  @Test
  public void test_getValue_7() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getValue(0, 0);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_8() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getValue(0, -1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_9() throws Exception {
    org.jfree.data.category.DefaultIntervalCategoryDataset obj = new org.jfree.data.category.DefaultIntervalCategoryDataset(new double[0][], new double[0][]);
    Throwable caught = null;
    try {
      obj.getValue(0, -10);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IllegalArgumentException", caught.getClass().getName());
  }
}
