import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.category.DefaultIntervalCategoryDataset;

import java.util.List;

public class DefaultIntervalCategoryDatasetTest {

    @Test
    public void testGetSeriesCount() {
        Number[][] startData = new Number[][] {
            {1.0, 2.0},
            {3.0, 4.0}
        };
        Number[][] endData = new Number[][] {
            {1.5, 2.5},
            {3.5, 4.5}
        };
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(startData, endData);
        Assert.assertEquals(2, dataset.getSeriesCount());
    }

    @Test
    public void testGetSeriesKey() {
        Comparable[] seriesKeys = new Comparable[] {"Series 1", "Series 2"};
        Comparable[] categoryKeys = new Comparable[] {"Category 1"};
        Number[][] startData = new Number[][] {
            {1.0},
            {3.0}
        };
        Number[][] endData = new Number[][] {
            {1.5},
            {3.5}
        };
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(seriesKeys, categoryKeys, startData, endData);
        Assert.assertEquals("Series 0", "Series 1", dataset.getSeriesKey(0));
        Assert.assertEquals("Series 1", "Series 2", dataset.getSeriesKey(1));
    }

    @Test
    public void testGetCategoryCount() {
        Number[][] startData = new Number[][] {
            {1.0, 2.0, 3.0}
        };
        Number[][] endData = new Number[][] {
            {1.5, 2.5, 3.5}
        };
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(startData, endData);
        Assert.assertEquals(3, dataset.getCategoryCount());
    }

    @Test
    public void testGetColumnKeys() {
        Comparable[] seriesKeys = new Comparable[] {"Series 1"};
        Comparable[] categoryKeys = new Comparable[] {"CatA", "CatB"};
        Number[][] startData = new Number[][] {
            {1.0, 2.0}
        };
        Number[][] endData = new Number[][] {
            {1.5, 2.5}
        };
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(seriesKeys, categoryKeys, startData, endData);
        List keys = dataset.getColumnKeys();
        Assert.assertNotNull(keys);
        Assert.assertEquals(2, keys.size());
        Assert.assertEquals("CatA", keys.get(0));
        Assert.assertEquals("CatB", keys.get(1));
    }

    @Test
    public void testGetValue() {
        Number[][] startData = new Number[][] {
            {1.0, 2.0}
        };
        Number[][] endData = new Number[][] {
            {1.5, 2.5}
        };
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(startData, endData);
        Number value = dataset.getValue(0, 1);
        Assert.assertEquals(2.5, value.doubleValue(), 0.0001);
    }
}
