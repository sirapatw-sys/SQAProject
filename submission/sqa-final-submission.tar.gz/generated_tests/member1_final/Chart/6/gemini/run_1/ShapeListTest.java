import org.junit.Test;
import org.junit.Assert;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;

public class ShapeListTest {

    @Test
    public void testGetShape() {
        ShapeList list = new ShapeList();
        Shape shape = new Rectangle2D.Double(0, 0, 10, 10);
        list.set(0, shape);
        
        Assert.assertEquals(shape, list.getShape(0));
        Assert.assertNull(list.getShape(1));
    }

    @Test
    public void testClone() throws CloneNotSupportedException {
        ShapeList list = new ShapeList();
        Shape shape = new Rectangle2D.Double(1, 2, 3, 4);
        list.set(0, shape);

        Object cloneObj = list.clone();
        Assert.assertTrue(cloneObj instanceof ShapeList);
        ShapeList clonedList = (ShapeList) cloneObj;
        Assert.assertEquals(shape, clonedList.getShape(0));
    }

    @Test
    public void testHashCode() {
        ShapeList list1 = new ShapeList();
        ShapeList list2 = new ShapeList();

        Assert.assertEquals(list1.hashCode(), list2.hashCode());
    }
}
