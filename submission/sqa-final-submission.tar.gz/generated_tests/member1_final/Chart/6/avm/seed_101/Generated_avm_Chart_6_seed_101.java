import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_6_seed_101 {
  @Test
  public void test_getShape_1() throws Exception {
    org.jfree.chart.util.ShapeList obj = new org.jfree.chart.util.ShapeList();
    assertNull(obj.getShape(0));
  }
  @Test
  public void test_getShape_2() throws Exception {
    org.jfree.chart.util.ShapeList obj = new org.jfree.chart.util.ShapeList();
    assertNull(obj.getShape(1));
  }
  @Test
  public void test_getShape_3() throws Exception {
    org.jfree.chart.util.ShapeList obj = new org.jfree.chart.util.ShapeList();
    assertNull(obj.getShape(-1));
  }
  @Test
  public void test_clone_4() throws Exception {
    org.jfree.chart.util.ShapeList obj = new org.jfree.chart.util.ShapeList();
    assertNotNull(obj.clone());
  }
  @Test
  public void test_hashCode_5() throws Exception {
    org.jfree.chart.util.ShapeList obj = new org.jfree.chart.util.ShapeList();
    assertEquals(4699, obj.hashCode());
  }
}
