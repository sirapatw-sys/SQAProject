import org.jfree.chart.util.ShapeList;
import org.junit.Assert;
import org.junit.Test;

public class ShapeListTest {

    @Test
    public void getShapeReturnsNullForUnusedIndexInNewList() {
        ShapeList list = new ShapeList();

        Assert.assertNull(list.getShape(0));
    }

    @Test
    public void cloneCreatesDistinctShapeListWithSameEmptyContents()
            throws CloneNotSupportedException {
        ShapeList original = new ShapeList();

        Object copy = original.clone();

        Assert.assertTrue(copy instanceof ShapeList);
        Assert.assertNotSame(original, copy);
        Assert.assertNull(((ShapeList) copy).getShape(0));
        Assert.assertNull(original.getShape(0));
    }

    @Test
    public void hashCodeMatchesForEquivalentEmptyShapeLists()
            throws CloneNotSupportedException {
        ShapeList list = new ShapeList();
        ShapeList clone = (ShapeList) list.clone();

        Assert.assertEquals(list.hashCode(), clone.hashCode());
        Assert.assertEquals(list.hashCode(), list.hashCode());
    }
}
