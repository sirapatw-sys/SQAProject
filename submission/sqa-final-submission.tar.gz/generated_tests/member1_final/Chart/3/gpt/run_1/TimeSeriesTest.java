import org.jfree.data.time.TimeSeries;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TimeSeriesTest {

    @Test
    public void testSetAndGetDomainDescription() {
        TimeSeries series = new TimeSeries("series");

        series.setDomainDescription("Date");
        assertEquals("Date", series.getDomainDescription());

        series.setDomainDescription(null);
        assertNull(series.getDomainDescription());
    }

    @Test
    public void testSetAndGetRangeDescription() {
        TimeSeries series = new TimeSeries("series");

        series.setRangeDescription("Value");
        assertEquals("Value", series.getRangeDescription());

        series.setRangeDescription(null);
        assertNull(series.getRangeDescription());
    }

    @Test
    public void testGetItemCountForNewSeries() {
        TimeSeries series = new TimeSeries("series");

        assertEquals(0, series.getItemCount());
    }
}
