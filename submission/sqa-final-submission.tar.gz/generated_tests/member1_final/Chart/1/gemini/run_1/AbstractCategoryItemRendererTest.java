import org.junit.Assert;
import org.junit.Test;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;

public class AbstractCategoryItemRendererTest {

    @Test
    public void testGetPassCount() {
        BarRenderer renderer = new BarRenderer();
        Assert.assertEquals(1, renderer.getPassCount());
    }

    @Test
    public void testGetPlot() {
        BarRenderer renderer = new BarRenderer();
        Assert.assertNull(renderer.getplot());
    }

    @Test
    public void testGetItemLabelGenerator() {
        BarRenderer renderer = new BarRenderer();
        CategoryItemLabelGenerator generator = renderer.getItemLabelGenerator(0, 0, false);
        Assert.assertNull(generator);
    }

    @Test
    public void testGetSeriesItemLabelGenerator() {
        BarRenderer renderer = new BarRenderer();
        CategoryItemLabelGenerator generator = renderer.getSeriesItemLabelGenerator(0);
        Assert.assertNull(generator);
    }

    @Test
    public void testGetBaseItemLabelGenerator() {
        BarRenderer renderer = new BarRenderer();
        Assert.assertNull(renderer.getBaseItemLabelGenerator());
        
        CategoryItemLabelGenerator generator = new StandardCategoryItemLabelGenerator();
        renderer.setBaseItemLabelGenerator(generator);
        Assert.assertEquals(generator, renderer.getBaseItemLabelGenerator());
    }
}
