import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_1_seed_101 {
  @Test
  public void test_getPassCount_1() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertEquals(1, obj.getPassCount());
  }
  @Test
  public void test_getPassCount_2() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBaseItemLabelGenerator(new org.jfree.chart.labels.IntervalCategoryItemLabelGenerator());
    assertEquals(1, obj.getPassCount());
  }
  @Test
  public void test_getPassCount_3() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertEquals(1, obj.getPassCount());
  }
  @Test
  public void test_getPlot_4() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getPlot());
  }
  @Test
  public void test_getPlot_5() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBaseItemLabelGenerator(new org.jfree.chart.labels.IntervalCategoryItemLabelGenerator());
    assertNull(obj.getPlot());
  }
  @Test
  public void test_getPlot_6() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBarPainter(new org.jfree.chart.renderer.category.GradientBarPainter());
    assertNull(obj.getPlot());
  }
  @Test
  public void test_getItemLabelGenerator_7() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getItemLabelGenerator(0, 0, false));
  }
  @Test
  public void test_getItemLabelGenerator_8() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBaseItemLabelGenerator(new org.jfree.chart.labels.IntervalCategoryItemLabelGenerator());
    assertNotNull(obj.getItemLabelGenerator(0, 0, false));
  }
  @Test
  public void test_getItemLabelGenerator_9() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getItemLabelGenerator(0, 100, false));
  }
  @Test
  public void test_getSeriesItemLabelGenerator_10() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getSeriesItemLabelGenerator(0));
  }
  @Test
  public void test_getSeriesItemLabelGenerator_11() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBaseItemLabelGenerator(new org.jfree.chart.labels.IntervalCategoryItemLabelGenerator());
    assertNull(obj.getSeriesItemLabelGenerator(0));
  }
  @Test
  public void test_getSeriesItemLabelGenerator_12() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getSeriesItemLabelGenerator(-10));
  }
  @Test
  public void test_getBaseItemLabelGenerator_13() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.setBaseItemLabelGenerator(new org.jfree.chart.labels.IntervalCategoryItemLabelGenerator());
    assertNotNull(obj.getBaseItemLabelGenerator());
  }
  @Test
  public void test_getBaseItemLabelGenerator_14() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0));
    assertNull(obj.getBaseItemLabelGenerator());
  }
  @Test
  public void test_getBaseItemLabelGenerator_15() throws Exception {
    org.jfree.chart.renderer.category.BarRenderer obj = new org.jfree.chart.renderer.category.BarRenderer();
    obj.addAnnotation(new org.jfree.chart.annotations.CategoryTextAnnotation("sqa", "sqa", 0.0), org.jfree.chart.util.Layer.BACKGROUND);
    assertNull(obj.getBaseItemLabelGenerator());
  }
}
