import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.renderer.category.BarRenderer;
import org.junit.Assert;
import org.junit.Test;

public class AbstractCategoryItemRendererTest {

    @Test
    public void getPassCountReturnsSinglePass() {
        BarRenderer renderer = new BarRenderer();

        Assert.assertEquals(1, renderer.getPassCount());
    }

    @Test
    public void getPlotReturnsNullForUnassignedRenderer() {
        BarRenderer renderer = new BarRenderer();

        Assert.assertNull(renderer.getPlot());
    }

    @Test
    public void getItemLabelGeneratorFallsBackToBaseGeneratorRegardlessOfSelection() {
        BarRenderer renderer = new BarRenderer();
        CategoryItemLabelGenerator generator = (CategoryItemLabelGenerator) Proxy.newProxyInstance(
                CategoryItemLabelGenerator.class.getClassLoader(),
                new Class[] { CategoryItemLabelGenerator.class },
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        return null;
                    }
                });

        renderer.setBaseItemLabelGenerator(generator);

        Assert.assertSame(generator, renderer.getItemLabelGenerator(0, 0, false));
        Assert.assertSame(generator, renderer.getItemLabelGenerator(0, 0, true));
    }

    @Test
    public void getSeriesItemLabelGeneratorReturnsNullWhenNoSeriesGeneratorIsConfigured() {
        BarRenderer renderer = new BarRenderer();

        Assert.assertNull(renderer.getSeriesItemLabelGenerator(0));
    }

    @Test
    public void getBaseItemLabelGeneratorReturnsConfiguredGenerator() {
        BarRenderer renderer = new BarRenderer();
        CategoryItemLabelGenerator generator = (CategoryItemLabelGenerator) Proxy.newProxyInstance(
                CategoryItemLabelGenerator.class.getClassLoader(),
                new Class[] { CategoryItemLabelGenerator.class },
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        return null;
                    }
                });

        renderer.setBaseItemLabelGenerator(generator);

        Assert.assertSame(generator, renderer.getBaseItemLabelGenerator());
    }
}
