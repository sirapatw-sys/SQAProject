import org.jfree.data.time.TimeSeries;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TimeSeriesTest {

    @Test
    public void testSetAndGetDomainDescriptionSupportsValuesAndNull() {
        TimeSeries series = new TimeSeries("series");

        series.setDomainDescription("Observation Date");
        assertEquals("Observation Date", series.getDomainDescription());

        series.setDomainDescription(null);
        assertNull(series.getDomainDescription());
    }

    @Test
    public void testSetAndGetRangeDescriptionSupportsValuesAndNull() {
        TimeSeries series = new TimeSeries("series");

        series.setRangeDescription("Closing Price");
        assertEquals("Closing Price", series.getRangeDescription());

        series.setRangeDescription(null);
        assertNull(series.getRangeDescription());
    }

    @Test
    public void testGetItemCountIsZeroForNewSeries() {
        TimeSeries series = new TimeSeries("series");

        assertEquals(0, series.getItemCount());
    }
}
