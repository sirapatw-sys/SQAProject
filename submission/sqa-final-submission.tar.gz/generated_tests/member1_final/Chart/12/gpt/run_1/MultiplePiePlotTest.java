import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.Test;

public class MultiplePiePlotTest {

    @Test
    public void testGetDatasetReflectsConfiguredDatasetAndNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series", "Category");

        MultiplePiePlot plot = new MultiplePiePlot(dataset);
        assertSame(dataset, plot.getDataset());

        plot.setDataset(null);
        assertNull(plot.getDataset());
    }

    @Test
    public void testGetPieChartReturnsConfiguredPieChart() {
        MultiplePiePlot plot = new MultiplePiePlot();
        assertNotNull(plot.getPieChart());

        JFreeChart replacement = new JFreeChart(new PiePlot());
        plot.setPieChart(replacement);

        assertSame(replacement, plot.getPieChart());
    }

    @Test
    public void testGetDataExtractOrderReturnsConfiguredOrder() {
        MultiplePiePlot plot = new MultiplePiePlot();

        plot.setDataExtractOrder(TableOrder.BY_ROW);
        assertSame(TableOrder.BY_ROW, plot.getDataExtractOrder());

        plot.setDataExtractOrder(TableOrder.BY_COLUMN);
        assertSame(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
    }

    @Test
    public void testGetLimitReturnsValueSetBySetter() {
        MultiplePiePlot plot = new MultiplePiePlot();

        plot.setLimit(0.35);
        assertEquals(0.35, plot.getLimit(), 0.0);
    }

    @Test
    public void testSetLimitAcceptsZeroAndNegativeValues() {
        MultiplePiePlot plot = new MultiplePiePlot();

        plot.setLimit(0.0);
        assertEquals(0.0, plot.getLimit(), 0.0);

        plot.setLimit(-0.25);
        assertEquals(-0.25, plot.getLimit(), 0.0);
    }
}
