import org.junit.Test;
import org.junit.Assert;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class MultiplePiePlotTest {

    @Test
    public void testGetDataset() {
        MultiplePiePlot plot = new MultiplePiePlot();
        Assert.assertNull(plot.getDataset());

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        plot.setDataset(dataset);
        Assert.assertSame(dataset, plot.getDataset());
    }

    @Test
    public void testGetPieChart() {
        MultiplePiePlot plot = new MultiplePiePlot();
        JFreeChart chart = plot.getPieChart();
        Assert.assertNotNull(chart);
    }

    @Test
    public void testGetDataExtractOrder() {
        MultiplePiePlot plot = new MultiplePiePlot();
        TableOrder order = plot.getDataExtractOrder();
        Assert.assertNotNull(order);
    }

    @Test
    public void testGetLimit() {
        MultiplePiePlot plot = new MultiplePiePlot();
        Assert.assertEquals(0.0, plot.getLimit(), 0.0001);
    }

    @Test
    public void testSetLimit() {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setLimit(0.05);
        Assert.assertEquals(0.05, plot.getLimit(), 0.0001);
    }
}
