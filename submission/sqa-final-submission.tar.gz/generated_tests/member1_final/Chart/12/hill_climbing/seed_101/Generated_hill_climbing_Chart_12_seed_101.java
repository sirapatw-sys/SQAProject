import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_hill_climbing_Chart_12_seed_101 {
  @Test
  public void test_getDataset_1() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    assertNull(obj.getDataset());
  }
  @Test
  public void test_getDataset_2() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataset(new org.jfree.data.category.DefaultCategoryDataset());
    assertNotNull(obj.getDataset());
  }
  @Test
  public void test_getDataset_3() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    assertNull(obj.getDataset());
  }
  @Test
  public void test_getPieChart_4() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    assertNotNull(obj.getPieChart());
  }
  @Test
  public void test_getPieChart_5() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataset(new org.jfree.data.category.DefaultCategoryDataset());
    assertNotNull(obj.getPieChart());
  }
  @Test
  public void test_getPieChart_6() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    assertNotNull(obj.getPieChart());
  }
  @Test
  public void test_getDataExtractOrder_7() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    assertNotNull(obj.getDataExtractOrder());
  }
  @Test
  public void test_getDataExtractOrder_8() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataset(new org.jfree.data.category.DefaultCategoryDataset());
    assertNotNull(obj.getDataExtractOrder());
  }
  @Test
  public void test_getDataExtractOrder_9() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    assertNotNull(obj.getDataExtractOrder());
  }
  @Test
  public void test_getLimit_10() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    assertEquals(0.0, obj.getLimit(), 1.0e-9);
  }
  @Test
  public void test_getLimit_11() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataset(new org.jfree.data.category.DefaultCategoryDataset());
    assertEquals(0.0, obj.getLimit(), 1.0e-9);
  }
  @Test
  public void test_getLimit_12() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    assertEquals(0.0, obj.getLimit(), 1.0e-9);
  }
  @Test
  public void test_setLimit_13() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    obj.setLimit(0.0);
    assertEquals(0.0, obj.getLimit(), 1.0e-9);
  }
  @Test
  public void test_setLimit_14() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    obj.setLimit(1.0);
    assertEquals(1.0, obj.getLimit(), 1.0e-9);
  }
  @Test
  public void test_setLimit_15() throws Exception {
    org.jfree.chart.plot.MultiplePiePlot obj = new org.jfree.chart.plot.MultiplePiePlot();
    obj.setAggregatedItemsKey("sqa");
    obj.setDataExtractOrder(org.jfree.chart.util.TableOrder.BY_COLUMN);
    obj.setLimit(-10.0);
    assertEquals(-10.0, obj.getLimit(), 1.0e-9);
  }
}
