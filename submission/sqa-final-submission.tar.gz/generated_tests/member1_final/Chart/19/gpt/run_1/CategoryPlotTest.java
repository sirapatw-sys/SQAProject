import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.RectangleInsets;
import org.junit.Assert;
import org.junit.Test;

public class CategoryPlotTest {

    @Test
    public void testGetPlotTypeReturnsLocalizedCategoryPlotName() {
        CategoryPlot plot = new CategoryPlot();

        Assert.assertEquals("Category Plot", plot.getPlotType());
    }

    @Test
    public void testGetOrientationReturnsNonNullDefaultOrientation() {
        CategoryPlot plot = new CategoryPlot();

        PlotOrientation orientation = plot.getOrientation();

        Assert.assertNotNull(orientation);
        Assert.assertSame(orientation, plot.getOrientation());
    }

    @Test
    public void testGetAxisOffsetReturnsNonNullStoredOffset() {
        CategoryPlot plot = new CategoryPlot();

        RectangleInsets offset = plot.getAxisOffset();

        Assert.assertNotNull(offset);
        Assert.assertSame(offset, plot.getAxisOffset());
    }

    @Test
    public void testGetDomainAxisReturnsNullWhenDefaultPlotHasNoAxis() {
        CategoryPlot plot = new CategoryPlot();

        Assert.assertNull(plot.getDomainAxis());
    }

    @Test
    public void testGetDomainAxisWithOutOfRangeIndexReturnsNull() {
        CategoryPlot plot = new CategoryPlot();

        CategoryAxis axis = plot.getDomainAxis(1000);

        Assert.assertNull(axis);
    }
}
