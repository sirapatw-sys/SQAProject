import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_18_seed_101 {
  @Test
  public void test_getItemCount_1() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    assertEquals(1, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_2() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.removeValue("sqa");
    assertEquals(0, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_3() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.setValue("sqa", 0);
    assertEquals(1, obj.getItemCount());
  }
  @Test
  public void test_getValue_4() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    assertEquals("0", String.valueOf(obj.getValue(0)));
  }
  @Test
  public void test_getValue_5() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.getValue(1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getValue_6() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.getValue(-1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getKey_7() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    assertEquals("sqa", String.valueOf(obj.getKey(0)));
  }
  @Test
  public void test_getKey_8() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.getKey(1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getKey_9() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.getKey(-1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_getKeys_10() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    assertNotNull(obj.getKeys());
  }
  @Test
  public void test_getKeys_11() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.removeValue("sqa");
    assertNotNull(obj.getKeys());
  }
  @Test
  public void test_getKeys_12() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.setValue("sqa", 0);
    assertNotNull(obj.getKeys());
  }
  @Test
  public void test_removeValue_13() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    obj.removeValue(0);
  }
  @Test
  public void test_removeValue_14() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.removeValue(1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
  @Test
  public void test_removeValue_15() throws Exception {
    org.jfree.data.DefaultKeyedValues obj = new org.jfree.data.DefaultKeyedValues();
    obj.addValue("sqa", 0);
    obj.sortByKeys(org.jfree.chart.util.SortOrder.ASCENDING);
    Throwable caught = null;
    try {
      obj.removeValue(-1);
    } catch (Throwable t) {
      caught = t;
    }
    assertNotNull("Expected an exception", caught);
    assertEquals("java.lang.IndexOutOfBoundsException", caught.getClass().getName());
  }
}
