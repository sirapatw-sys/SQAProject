import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.DefaultKeyedValues;

import java.util.List;

public class DefaultKeyedValuesTest {

    @Test
    public void testGetItemCount() {
        DefaultKeyedValues data = new DefaultKeyedValues();
        Assert.assertEquals(0, data.getItemCount());
        data.addValue("Key1", 10.5);
        Assert.assertEquals(1, data.getItemCount());
    }

    @Test
    public void testGetValueByIndex() {
        DefaultKeyedValues data = new DefaultKeyedValues();
        data.addValue("Key1", 42);
        Number value = data.getValue(0);
        Assert.assertEquals(42, value.intValue());
    }

    @Test
    public void testGetKey() {
        DefaultKeyedValues data = new DefaultKeyedValues();
        data.addValue("Key1", 10);
        Comparable key = data.getKey(0);
        Assert.assertEquals("Key1", key);
    }

    @Test
    public void testGetKeys() {
        DefaultKeyedValues data = new DefaultKeyedValues();
        data.addValue("KeyA", 1);
        data.addValue("KeyB", 2);
        List keys = data.getKeys();
        Assert.assertNotNull(keys);
        Assert.assertEquals(2, keys.size());
        Assert.assertEquals("KeyA", keys.get(0));
        Assert.assertEquals("KeyB", keys.get(1));
    }

    @Test
    public void testRemoveValueByIndex() {
        DefaultKeyedValues data = new DefaultKeyedValues();
        data.addValue("Key1", 100);
        data.addValue("Key2", 200);
        data.removeValue(0);
        Assert.assertEquals(1, data.getItemCount());
        Assert.assertEquals("Key2", data.getKey(0));
        Assert.assertEquals(200, data.getValue(0).intValue());
    }

}
