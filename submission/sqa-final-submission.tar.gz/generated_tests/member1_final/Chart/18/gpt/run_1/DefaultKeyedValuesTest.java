import java.util.Arrays;
import java.util.List;

import org.jfree.data.DefaultKeyedValues;
import org.junit.Assert;
import org.junit.Test;

public class DefaultKeyedValuesTest {

    @Test
    public void testGetItemCountReflectsAddedItems() {
        DefaultKeyedValues values = new DefaultKeyedValues();

        Assert.assertEquals(0, values.getItemCount());

        values.addValue("first", Integer.valueOf(10));
        values.addValue("second", Integer.valueOf(20));
        values.addValue("third", Integer.valueOf(30));

        Assert.assertEquals(3, values.getItemCount());
    }

    @Test
    public void testGetValueReturnsValueAtIndexAndRejectsInvalidIndex() {
        DefaultKeyedValues values = new DefaultKeyedValues();
        values.addValue("first", Integer.valueOf(10));
        values.addValue("second", Integer.valueOf(20));

        Assert.assertEquals(Integer.valueOf(10), values.getValue(0));
        Assert.assertEquals(Integer.valueOf(20), values.getValue(1));

        try {
            values.getValue(2);
            Assert.fail("Expected IndexOutOfBoundsException for an invalid item index");
        } catch (IndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testGetKeyReturnsKeyAtIndexAndRejectsInvalidIndex() {
        DefaultKeyedValues values = new DefaultKeyedValues();
        values.addValue("alpha", Integer.valueOf(1));
        values.addValue("beta", Integer.valueOf(2));

        Assert.assertEquals("alpha", values.getKey(0));
        Assert.assertEquals("beta", values.getKey(1));

        try {
            values.getKey(-1);
            Assert.fail("Expected IndexOutOfBoundsException for a negative item index");
        } catch (IndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testGetKeysReturnsIndependentListContainingKeysInOrder() {
        DefaultKeyedValues values = new DefaultKeyedValues();
        values.addValue("alpha", Integer.valueOf(1));
        values.addValue("beta", Integer.valueOf(2));

        List keys = values.getKeys();

        Assert.assertEquals(Arrays.asList("alpha", "beta"), keys);

        keys.clear();

        Assert.assertEquals(Arrays.asList("alpha", "beta"), values.getKeys());
    }

    @Test
    public void testRemoveValueByIndexRemovesMatchingKeyAndValue() {
        DefaultKeyedValues values = new DefaultKeyedValues();
        values.addValue("first", Integer.valueOf(10));
        values.addValue("middle", Integer.valueOf(20));
        values.addValue("last", Integer.valueOf(30));

        values.removeValue(1);

        Assert.assertEquals(2, values.getItemCount());
        Assert.assertEquals("first", values.getKey(0));
        Assert.assertEquals(Integer.valueOf(10), values.getValue(0));
        Assert.assertEquals("last", values.getKey(1));
        Assert.assertEquals(Integer.valueOf(30), values.getValue(1));
    }
}
