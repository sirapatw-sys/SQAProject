import org.junit.Test;
import static org.junit.Assert.*;

public class Generated_avm_Chart_7_seed_101 {
  @Test
  public void test_getDomainDescription_1() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    assertEquals("Time", obj.getDomainDescription());
  }
  @Test
  public void test_getDomainDescription_2() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.TimePeriodValue(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0));
    assertEquals("Time", obj.getDomainDescription());
  }
  @Test
  public void test_getDomainDescription_3() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.update(0, 0);
    assertEquals("Time", obj.getDomainDescription());
  }
  @Test
  public void test_setDomainDescription_4() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setDomainDescription("");
    assertEquals("", obj.getDomainDescription());
  }
  @Test
  public void test_setDomainDescription_5() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setDomainDescription("a");
    assertEquals("a", obj.getDomainDescription());
  }
  @Test
  public void test_setDomainDescription_6() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setDomainDescription("0");
    assertEquals("0", obj.getDomainDescription());
  }
  @Test
  public void test_getRangeDescription_7() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    assertEquals("Value", obj.getRangeDescription());
  }
  @Test
  public void test_getRangeDescription_8() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.TimePeriodValue(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0));
    assertEquals("Value", obj.getRangeDescription());
  }
  @Test
  public void test_getRangeDescription_9() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.update(0, 0);
    assertEquals("Value", obj.getRangeDescription());
  }
  @Test
  public void test_setRangeDescription_10() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setRangeDescription("");
    assertEquals("", obj.getRangeDescription());
  }
  @Test
  public void test_setRangeDescription_11() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setRangeDescription("a");
    assertEquals("a", obj.getRangeDescription());
  }
  @Test
  public void test_setRangeDescription_12() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    obj.setRangeDescription("0");
    assertEquals("0", obj.getRangeDescription());
  }
  @Test
  public void test_getItemCount_13() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0.0);
    assertEquals(2, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_14() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    obj.add(new org.jfree.data.time.SimpleTimePeriod(0L, 0L), 0);
    obj.update(0, 0);
    assertEquals(1, obj.getItemCount());
  }
  @Test
  public void test_getItemCount_15() throws Exception {
    org.jfree.data.time.TimePeriodValues obj = new org.jfree.data.time.TimePeriodValues("sqa");
    assertEquals(0, obj.getItemCount());
  }
}
