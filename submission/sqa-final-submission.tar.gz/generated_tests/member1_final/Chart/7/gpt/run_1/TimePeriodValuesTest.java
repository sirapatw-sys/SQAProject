import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.jfree.data.time.TimePeriodValues;
import org.junit.Test;

public class TimePeriodValuesTest {

    @Test
    public void domainDescriptionCanBeSetAndCleared() {
        TimePeriodValues values = new TimePeriodValues("series");

        values.setDomainDescription("Observation Date");
        assertEquals("Observation Date", values.getDomainDescription());

        values.setDomainDescription(null);
        assertNull(values.getDomainDescription());
    }

    @Test
    public void rangeDescriptionCanBeSetAndCleared() {
        TimePeriodValues values = new TimePeriodValues("series");

        values.setRangeDescription("Temperature");
        assertEquals("Temperature", values.getRangeDescription());

        values.setRangeDescription(null);
        assertNull(values.getRangeDescription());
    }

    @Test
    public void newSeriesHasNoItems() {
        TimePeriodValues values = new TimePeriodValues("series");

        assertEquals(0, values.getItemCount());
    }
}
