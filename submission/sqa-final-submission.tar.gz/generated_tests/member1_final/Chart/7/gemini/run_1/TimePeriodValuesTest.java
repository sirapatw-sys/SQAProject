import org.junit.Assert;
import org.junit.Test;
import org.jfree.data.time.TimePeriodValues;
import org.jfree.data.time.SimpleTimePeriod;
import java.util.Date;

public class TimePeriodValuesTest {

    @Test
    public void testGetDomainDescription() {
        TimePeriodValues series = new TimePeriodValues("Test Series", "DomainDesc", "RangeDesc");
        Assert.assertEquals("DomainDesc", series.getDomainDescription());
    }

    @Test
    public void testSetDomainDescription() {
        TimePeriodValues series = new TimePeriodValues("Test Series");
        series.setDomainDescription("NewDomain");
        Assert.assertEquals("NewDomain", series.getDomainDescription());
    }

    @Test
    public void testGetRangeDescription() {
        TimePeriodValues series = new TimePeriodValues("Test Series", "DomainDesc", "RangeDesc");
        Assert.assertEquals("RangeDesc", series.getRangeDescription());
    }

    @Test
    public void testSetRangeDescription() {
        TimePeriodValues series = new TimePeriodValues("Test Series");
        series.setRangeDescription("NewRange");
        Assert.assertEquals("NewRange", series.getRangeDescription());
    }

    @Test
    public void testGetItemCount() {
        TimePeriodValues series = new TimePeriodValues("Test Series");
        Assert.assertEquals(0, series.getItemCount());
        
        series.add(new SimpleTimePeriod(new Date(0L), new Date(1000L)), 5.0);
        Assert.assertEquals(1, series.getItemCount());
    }
}
